/*
  # CGS Leads Database Schema

  1. New Tables
    - `leads`
      - `id` (uuid, primary key)
      - `name` (text, required) - Lead's full name
      - `email` (text, required) - Lead's email address
      - `phone` (text, optional) - Lead's phone number
      - `business_type` (text, required) - Type of business (Gym, Roofer, Dentist, Coach, Advisor, Other)
      - `website_url` (text, optional) - Lead's business website
      - `pain_point` (text, optional) - Their biggest business pain point
      - `source` (text, optional) - Where the lead came from (homepage, contact, etc.)
      - `niche_param` (text, optional) - URL personalization param used
      - `created_at` (timestamptz) - Submission timestamp
      - `email_sent` (boolean) - Whether welcome email was sent
      - `nurture_day` (integer) - Current day in nurture sequence
    
    - `admin_users`
      - `id` (uuid, primary key)
      - `username` (text, unique, required)
      - `password_hash` (text, required) - Hashed password
      - `created_at` (timestamptz)
      - `last_login` (timestamptz)

    - `blog_views`
      - `id` (uuid, primary key)
      - `article_slug` (text, required)
      - `view_count` (integer)
      - `last_viewed` (timestamptz)

  2. Security
    - Enable RLS on all tables
    - Leads table: Service role can insert/read, no public access
    - Admin users: Only service role access
*/

-- Create leads table
CREATE TABLE IF NOT EXISTS leads (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  email text NOT NULL,
  phone text,
  business_type text NOT NULL,
  website_url text,
  pain_point text,
  source text DEFAULT 'website',
  niche_param text,
  created_at timestamptz DEFAULT now(),
  email_sent boolean DEFAULT false,
  nurture_day integer DEFAULT 0
);

-- Create admin_users table
CREATE TABLE IF NOT EXISTS admin_users (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  username text UNIQUE NOT NULL,
  password_hash text NOT NULL,
  created_at timestamptz DEFAULT now(),
  last_login timestamptz
);

-- Create blog_views table for analytics
CREATE TABLE IF NOT EXISTS blog_views (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  article_slug text UNIQUE NOT NULL,
  view_count integer DEFAULT 0,
  last_viewed timestamptz DEFAULT now()
);

-- Create indexes for common queries
CREATE INDEX IF NOT EXISTS idx_leads_email ON leads(email);
CREATE INDEX IF NOT EXISTS idx_leads_business_type ON leads(business_type);
CREATE INDEX IF NOT EXISTS idx_leads_created_at ON leads(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_admin_username ON admin_users(username);

-- Enable RLS
ALTER TABLE leads ENABLE ROW LEVEL SECURITY;
ALTER TABLE admin_users ENABLE ROW LEVEL SECURITY;
ALTER TABLE blog_views ENABLE ROW LEVEL SECURITY;

-- RLS Policies for leads (service role only for now, will add anon insert)
CREATE POLICY "Service role can manage leads"
  ON leads
  FOR ALL
  TO service_role
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Anonymous users can insert leads"
  ON leads
  FOR INSERT
  TO anon
  WITH CHECK (true);

-- RLS Policies for admin_users
CREATE POLICY "Service role can manage admin users"
  ON admin_users
  FOR ALL
  TO service_role
  USING (true)
  WITH CHECK (true);

-- RLS Policies for blog_views
CREATE POLICY "Service role can manage blog views"
  ON blog_views
  FOR ALL
  TO service_role
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Anonymous can read and update blog views"
  ON blog_views
  FOR SELECT
  TO anon
  USING (true);

-- Insert default admin user (password: cgs2026, using simple hash for demo)
-- In production, use proper bcrypt hashing
INSERT INTO admin_users (username, password_hash)
VALUES ('admin', 'cgs2026_hashed')
ON CONFLICT (username) DO NOTHING;

-- Insert initial blog view records
INSERT INTO blog_views (article_slug, view_count)
VALUES 
  ('lead-funnel-guide', 0),
  ('ad-mistakes', 0),
  ('local-seo-goldmine', 0),
  ('email-automation', 0),
  ('ai-marketing', 0)
ON CONFLICT (article_slug) DO NOTHING;