/*
  # Create Settings Table for Social Links Management

  1. New Tables
    - `settings`
      - `id` (uuid, primary key) - Unique identifier
      - `instagram_url` (text) - Instagram profile URL
      - `linkedin_url` (text) - LinkedIn profile URL
      - `twitter_url` (text) - Twitter profile URL
      - `facebook_url` (text) - Facebook profile URL
      - `created_at` (timestamptz) - Creation timestamp
      - `updated_at` (timestamptz) - Last update timestamp

  2. Security
    - Enable RLS on `settings` table
    - Add policy for public read access (social links are public)
    - Add policy for authenticated users to update settings (simplified)

  3. Initial Data
    - Insert default social links for Client Growth Systems
*/

CREATE TABLE IF NOT EXISTS settings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  instagram_url text DEFAULT 'https://instagram.com/cgsleads',
  linkedin_url text DEFAULT 'https://www.linkedin.com/company/client-growth-systems',
  twitter_url text DEFAULT 'https://twitter.com/cgrowthsystems',
  facebook_url text DEFAULT 'https://facebook.com/clientgrowthsystems',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE settings ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view settings"
  ON settings
  FOR SELECT
  USING (true);

CREATE POLICY "Authenticated users can update settings"
  ON settings
  FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM settings LIMIT 1) THEN
    INSERT INTO settings (instagram_url, linkedin_url, twitter_url, facebook_url)
    VALUES (
      'https://instagram.com/cgsleads',
      'https://www.linkedin.com/company/client-growth-systems',
      'https://twitter.com/cgrowthsystems',
      'https://facebook.com/clientgrowthsystems'
    );
  END IF;
END $$;