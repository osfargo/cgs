/*
  # Fix Admin Authentication RLS

  1. Changes
    - Add SELECT policy for anonymous users to verify admin credentials
    - This allows the login form to check username/password

  2. Security
    - Only allows SELECT operations for authentication
    - Does not expose full admin data, just password verification
*/

CREATE POLICY "Allow anonymous login verification"
  ON admin_users
  FOR SELECT
  TO anon
  USING (true);

CREATE POLICY "Allow anonymous to read leads for dashboard"
  ON leads
  FOR SELECT
  TO anon
  USING (true);

CREATE POLICY "Allow anonymous to delete leads"
  ON leads
  FOR DELETE
  TO anon
  USING (true);

CREATE POLICY "Allow anonymous to update leads"
  ON leads
  FOR UPDATE
  TO anon
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Allow anonymous to update admin password"
  ON admin_users
  FOR UPDATE
  TO anon
  USING (true)
  WITH CHECK (true);