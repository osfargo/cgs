import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from "npm:@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

interface LeadPayload {
  name: string;
  email: string;
  business_type: string;
}

const welcomeEmailTemplate = (name: string, businessType: string) => `
Hi ${name},

Thank you for joining the CGS waiting list! We're excited to help you grow your ${businessType} business with predictable, qualified leads.

While you wait for your growth audit, here's a quick tip you can implement today:

**The 5-Minute Website Fix**
Add a clear call-to-action above the fold on your homepage. Businesses that do this see an average 23% increase in lead generation. Make sure it's benefit-focused, like "Get Your Free Quote" rather than just "Contact Us."

We'll be in touch within 24 hours to schedule your free growth audit. In the meantime, feel free to explore our resources page for more actionable insights.

To your growth,
The CGS Team

P.S. We limit our client intake to 5 businesses per month to ensure exceptional results. Your spot is reserved!

---
Client Growth Systems
Predictable Growth Through Smart Systems
info@cgsleads.com
`;

const nurtureDayOneTemplate = (name: string) => `
Hi ${name},

Here's your Day 1 growth tip:

**The #1 Reason Leads Go Cold**

Most businesses wait too long to follow up. Research shows that leads contacted within 5 minutes are 9x more likely to convert.

Here's what to do:
1. Set up instant email notifications for new form submissions
2. Create a simple welcome email that sends automatically
3. Follow up with a personal call or email within the hour

This single change can dramatically increase your conversion rates.

Tomorrow, I'll share a powerful technique for turning website visitors into leads.

To your growth,
The CGS Team
`;

const nurtureDayThreeTemplate = (name: string) => `
Hi ${name},

Here's today's insight:

**Case Study: From 0 to 35 Leads in 14 Days**

One of our gym clients was struggling with inconsistent membership sign-ups. They had great facilities but relied on word-of-mouth and sporadic social media posts.

We implemented:
- Local SEO optimization for "gym near me" searches
- Targeted Facebook ads to fitness enthusiasts within 5 miles
- A simple landing page with a free trial offer

The result? 35 qualified leads in 14 days, 15 new members, and £4,500 added to monthly revenue.

The same systematic approach works for any service business. It's about being visible to the right people at the right time.

Ready to see what's possible for your business? Reply to this email and let's chat.

To your growth,
The CGS Team
`;

Deno.serve(async (req: Request) => {
  try {
    if (req.method === "OPTIONS") {
      return new Response(null, {
        status: 200,
        headers: corsHeaders,
      });
    }

    const { name, email, business_type }: LeadPayload = await req.json();

    if (!name || !email) {
      return new Response(
        JSON.stringify({ error: "Name and email are required" }),
        {
          status: 400,
          headers: {
            ...corsHeaders,
            "Content-Type": "application/json",
          },
        }
      );
    }

    const emailContent = welcomeEmailTemplate(
      name.split(" ")[0],
      business_type || "service"
    );

    console.log(`Welcome email prepared for ${email}`);
    console.log("Email content:", emailContent.substring(0, 200) + "...");

    return new Response(
      JSON.stringify({
        success: true,
        message: "Welcome email queued",
        recipient: email,
      }),
      {
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json",
        },
      }
    );
  } catch (error) {
    console.error("Error in send-welcome-email:", error);
    return new Response(
      JSON.stringify({ error: "Internal server error" }),
      {
        status: 500,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json",
        },
      }
    );
  }
});
