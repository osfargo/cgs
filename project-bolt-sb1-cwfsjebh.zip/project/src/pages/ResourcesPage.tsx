import { useState } from 'react';
import { motion } from 'framer-motion';
import {
  Download,
  ChevronDown,
  ChevronUp,
  CheckCircle,
  Lightbulb,
  ArrowRight
} from 'lucide-react';
import AnimatedSection from '../components/AnimatedSection';
import LeadForm from '../components/LeadForm';

const articles = [
  {
    id: 'lead-funnel',
    title: 'How to Build a Lead Funnel That Converts 24/7',
    excerpt: 'A step-by-step guide to creating an automated system that captures and nurtures leads around the clock.',
    readTime: '8 min read',
    content: `
      Most businesses treat their website like a digital business card—it sits there, looks nice, but doesn't actively work to bring in customers. A lead funnel changes that. It's a systematic approach to capturing visitor information and guiding them toward becoming a customer.

      ## What is a Lead Funnel?

      A lead funnel is a series of connected pages and automated sequences designed to:
      - Capture visitor attention with a compelling offer
      - Collect contact information in exchange for value
      - Nurture leads through automated follow-up
      - Convert interested prospects into paying customers

      ## The Anatomy of a High-Converting Funnel

      ### 1. Traffic Source
      Every funnel starts with traffic. This could come from paid ads, SEO, social media, or referrals. The key is understanding where your ideal customers spend time online and meeting them there.

      ### 2. Landing Page
      Your landing page has one job: get the visitor to take a specific action. This means:
      - A clear, benefit-focused headline
      - Minimal distractions (no navigation menu)
      - Social proof (testimonials, logos, numbers)
      - A compelling offer (free guide, consultation, trial)
      - A prominent call-to-action

      ### 3. Lead Capture Form
      Keep it simple. Every additional field reduces conversions. For most businesses, name and email is enough to start. You can collect more information later.

      ### 4. Thank You Page
      Don't waste this valuable real estate. Your thank you page should:
      - Confirm their action was successful
      - Set expectations for what happens next
      - Offer an additional next step (book a call, join a community)

      ### 5. Email Sequence
      This is where the magic happens. Your email sequence should:
      - Welcome them immediately (within 5 minutes)
      - Deliver the promised value
      - Provide additional helpful content
      - Make a clear offer when appropriate

      ## Free Tip: The 3-3-3 Formula

      Your first three emails should be sent over three days, each taking about three minutes to read:
      - Day 0: Welcome + deliver the lead magnet
      - Day 1: Share a quick win they can implement today
      - Day 3: Tell a story about a successful customer

      This sequence builds trust and keeps you top of mind without being pushy.

      ## Common Mistakes to Avoid

      - Asking for too much information upfront
      - Generic headlines that don't address specific pain points
      - Slow page load times (aim for under 3 seconds)
      - No mobile optimization
      - Ignoring follow-up (most leads need 5-7 touchpoints)

      ## Your Next Step

      Start by mapping out your customer journey. What are the key questions they have before buying? Create content that answers those questions and use it to build your first funnel. Even a simple landing page with an email sequence can transform your lead generation.
    `
  },
  {
    id: 'ad-mistakes',
    title: 'The #1 Mistake Businesses Make with Ads (And How to Fix It)',
    excerpt: 'Why most advertising campaigns fail and the simple strategy that turns wasted spend into profitable customer acquisition.',
    readTime: '7 min read',
    content: `
      Every month, businesses waste thousands on advertising that doesn't work. They boost posts, run "brand awareness" campaigns, and wonder why the phone isn't ringing. The problem isn't the platform—it's the approach.

      ## The Biggest Mistake: Optimizing for the Wrong Metric

      Here's what most businesses do: they run ads optimized for reach, impressions, or engagement. They see thousands of views and hundreds of likes, and assume it's working. But likes don't pay bills.

      The fix is simple: optimize for conversions, not vanity metrics.

      ## Understanding the Advertising Funnel

      Not all ads should have the same goal. Think of advertising in three stages:

      ### Cold Traffic (Awareness)
      These people don't know you exist. Your ads should:
      - Introduce your brand and what you do
      - Address a pain point they're experiencing
      - Offer something valuable (free guide, video, tips)

      ### Warm Traffic (Consideration)
      These people have interacted with your content. Your ads should:
      - Remind them of the problem you solve
      - Share social proof and testimonials
      - Invite them to take a specific action

      ### Hot Traffic (Decision)
      These people are close to buying. Your ads should:
      - Create urgency (limited spots, deadline)
      - Address final objections
      - Make a clear, compelling offer

      ## The Right Way to Structure Your Campaigns

      ### Step 1: Define Your Conversion Goal
      What action do you want people to take? Book a call? Fill out a form? Purchase? Be specific.

      ### Step 2: Create Your Landing Page First
      Your ad is only as good as where it sends people. Before running a single ad, ensure your landing page is optimized for conversions.

      ### Step 3: Start Small and Test
      Don't spend £1,000 on day one. Start with £20-50 per day and test:
      - 3-4 different ad creatives (images or videos)
      - 2-3 different headlines
      - 2 different audience segments

      ### Step 4: Let Data Guide Decisions
      After 7 days with meaningful data (at least 1,000 impressions per variation), analyze:
      - Click-through rate (CTR): Are people interested?
      - Cost per click (CPC): Is traffic affordable?
      - Conversion rate: Are clicks becoming leads?

      ### Step 5: Double Down on Winners
      Kill the underperformers and increase budget on what's working. Repeat.

      ## Free Tip: The 80/20 Rule of Ad Creative

      Spend 80% of your creative time on the hook—the first line of copy or first 3 seconds of video. This is what determines whether someone stops scrolling. A great hook can make an average ad perform well; a bad hook will sink even the best offer.

      ## Metrics That Actually Matter

      Forget impressions. Focus on:
      - Cost Per Lead (CPL): What are you paying per qualified lead?
      - Cost Per Acquisition (CPA): What does a customer cost to acquire?
      - Return on Ad Spend (ROAS): For every pound spent, how much revenue generated?

      ## Your Action Plan

      This week, audit your current advertising:
      1. What are you optimizing for? If it's not conversions, change it.
      2. Do you have a dedicated landing page? If not, create one.
      3. Are you testing multiple creatives? Start today.

      The businesses that win with advertising aren't necessarily spending more—they're spending smarter.
    `
  },
  {
    id: 'local-seo',
    title: 'Why Local SEO is the Free Lead Goldmine',
    excerpt: 'How to dominate local search results and capture customers actively looking for your services—without spending on ads.',
    readTime: '9 min read',
    content: `
      When someone searches "gym near me" or "roofer in [city]," they're not browsing—they're ready to buy. Local SEO puts your business in front of these high-intent customers, and unlike paid advertising, the traffic is free.

      ## Understanding Local Search

      Google handles over 5 billion searches daily. Nearly half of all searches have local intent. When someone searches for a local service:
      - 76% visit a business within 24 hours
      - 28% of those searches result in a purchase
      - 88% of searches on mobile devices result in a call or visit within a day

      These aren't casual browsers. They're customers looking for a solution right now.

      ## The Three Pillars of Local SEO

      ### 1. Google Business Profile (GBP)

      Your GBP is the foundation of local SEO. It's free, and it's often the first thing potential customers see. Optimization checklist:

      - Complete every section (hours, services, attributes)
      - Add high-quality photos (businesses with photos get 42% more direction requests)
      - Choose the right categories (primary and secondary)
      - Write a compelling business description with keywords
      - Keep information consistent with your website

      ### 2. Reviews and Reputation

      Reviews are the social proof of local search. They influence both rankings and click-through rates.

      Strategies for getting more reviews:
      - Ask satisfied customers directly (timing matters—ask right after a positive interaction)
      - Make it easy with a direct review link
      - Respond to every review, positive or negative
      - Never buy fake reviews (Google's algorithm will catch you)

      ### 3. Local Content and Citations

      Create content that targets local keywords:
      - "[Service] in [City]" pages
      - Local guides and resources
      - Case studies featuring local clients

      Build citations (mentions of your business name, address, phone):
      - Industry directories
      - Local business associations
      - Chamber of commerce

      ## Free Tip: The Review Response Template

      For positive reviews: "Thank you [Name] for the kind words! We loved working with you on [specific project/service]. Looking forward to seeing you again soon."

      For negative reviews: "Thank you for bringing this to our attention, [Name]. We're sorry your experience didn't meet expectations. Please contact us at [email] so we can make this right."

      Always respond within 24 hours. This shows Google (and potential customers) that you're an engaged business.

      ## Quick Wins You Can Implement Today

      ### Week 1: GBP Audit
      - Verify your profile is claimed and complete
      - Add 5-10 high-quality photos
      - Ensure NAP (Name, Address, Phone) is consistent everywhere

      ### Week 2: Review Campaign
      - Create a review request process
      - Respond to all existing reviews
      - Set up alerts for new reviews

      ### Week 3: Local Content
      - Create a location-specific page on your website
      - Add schema markup for local business
      - Submit to top 10 local directories

      ### Week 4: Monitor and Optimize
      - Track rankings for target keywords
      - Monitor GBP insights
      - Adjust strategy based on data

      ## The Long-Term Play

      Local SEO isn't a one-time project—it's an ongoing process. But the investment pays dividends. Unlike paid ads where traffic stops when you stop paying, strong local SEO delivers free leads indefinitely.

      The businesses dominating local search in your area aren't necessarily better than you—they've just optimized their online presence. Start today, and within 3-6 months, you'll see the results.
    `
  },
  {
    id: 'email-automation',
    title: 'Email Automation: Turn Leads Into Customers Automatically',
    excerpt: 'How to set up email sequences that nurture prospects and close sales while you sleep.',
    readTime: '10 min read',
    content: `
      You generate leads, but they go cold. You follow up manually, but it's inconsistent. You know email works, but you don't have time to send individual messages. Sound familiar?

      Email automation solves all of this. It's your 24/7 sales assistant that never forgets to follow up, never gets tired, and consistently nurtures every single lead.

      ## Why Email Automation Matters

      The numbers are compelling:
      - Email marketing returns £42 for every £1 spent
      - Automated emails generate 320% more revenue than non-automated
      - Leads nurtured with email make 47% larger purchases

      But here's the key insight: most leads aren't ready to buy immediately. They need time, information, and trust. Automation provides all three consistently.

      ## The Essential Email Sequences

      ### 1. Welcome Sequence (5-7 emails)

      This is your first impression. Goals:
      - Deliver promised value (lead magnet)
      - Introduce yourself and your business
      - Build trust and credibility
      - Make a soft offer

      Timing: Email 1 immediately, then daily for 5-7 days

      ### 2. Nurture Sequence (Ongoing)

      For leads not ready to buy. Goals:
      - Stay top of mind
      - Provide ongoing value
      - Build relationship over time

      Timing: Weekly or bi-weekly, indefinitely

      ### 3. Sales Sequence (3-5 emails)

      When a lead shows buying signals. Goals:
      - Present your offer clearly
      - Handle objections
      - Create urgency
      - Close the sale

      Timing: Over 5-7 days with increasing urgency

      ### 4. Re-engagement Sequence (3-4 emails)

      For cold leads who've stopped engaging. Goals:
      - Reignite interest
      - Clean your list of inactive contacts
      - Recover potentially lost customers

      Timing: After 30-60 days of no engagement

      ## Free Tip: The Perfect Welcome Email Formula

      Subject: [First Name], here's your [Lead Magnet]

      Body structure:
      1. Thank them for signing up (1 sentence)
      2. Deliver what you promised (link to download)
      3. Set expectations for future emails (1-2 sentences)
      4. Quick introduction of yourself (2-3 sentences)
      5. One helpful tip they can use today (3-4 sentences)
      6. Simple sign-off with PS about next email

      This email should be short, valuable, and personal. Save the selling for later.

      ## Automation Best Practices

      ### Personalization Beyond [First Name]
      Use behavior-based personalization:
      - What pages they visited
      - What content they downloaded
      - How they came to your site

      ### Timing Matters
      - Welcome email: Within 5 minutes of sign-up
      - Follow-ups: Test different times
      - Consider time zones if you have a national audience

      ### Test Everything
      A/B test your subject lines. Even small improvements compound over thousands of emails.

      ### Clean Your List Regularly
      Remove unengaged contacts every quarter. A smaller, engaged list performs better than a large, cold one.

      ## Tools to Get Started

      You don't need expensive software to begin. Options:
      - Free tier: MailerLite, Brevo (formerly Sendinblue)
      - Mid-range: ConvertKit, ActiveCampaign
      - Advanced: Klaviyo, HubSpot

      Start simple. You can always upgrade as you scale.

      ## Your 30-Day Implementation Plan

      Week 1: Set up your email platform and welcome sequence
      Week 2: Create your first nurture sequence
      Week 3: Build a simple sales sequence
      Week 4: Set up tracking and make first optimizations

      ## The Bottom Line

      Email automation isn't about replacing human connection—it's about extending it. You can't personally follow up with every lead, but automation ensures no one falls through the cracks.

      Start with a simple welcome sequence. Once that's working, add more. Within a few months, you'll have a system that generates revenue while you focus on running your business.
    `
  },
  {
    id: 'ai-marketing',
    title: 'AI in Marketing: Simple Ways to Personalize for More Sales',
    excerpt: 'Practical applications of AI that small businesses can use today to improve marketing results.',
    readTime: '11 min read',
    content: `
      AI isn't science fiction—it's a practical tool that businesses of all sizes can use today. You don't need a tech team or massive budget. With the right approach, AI can help you personalize marketing, save time, and increase conversions.

      ## What AI Can Actually Do for Your Marketing

      Let's cut through the hype. Here's what AI realistically helps with:

      ### Content Creation
      AI tools can help you:
      - Draft email copy and social media posts
      - Generate blog post outlines
      - Write ad variations for testing
      - Create personalized content at scale

      ### Personalization
      AI enables:
      - Dynamic website content based on visitor behavior
      - Personalized email content
      - Product recommendations
      - Targeted messaging for different segments

      ### Analysis and Insights
      AI excels at:
      - Identifying patterns in customer data
      - Predicting which leads are most likely to convert
      - Optimizing ad spend allocation
      - Understanding sentiment from reviews and feedback

      ### Automation
      AI powers:
      - Chatbots that handle basic inquiries
      - Lead scoring and prioritization
      - Campaign optimization
      - Customer service routing

      ## Practical AI Applications You Can Implement Today

      ### 1. URL-Based Personalization

      Use URL parameters to show different content to different audiences. For example:
      - yoursite.com?niche=gym shows gym-specific content
      - yoursite.com?niche=roofer shows roofing content

      This simple technique can increase conversions by 30-40%.

      ### 2. AI-Powered Chatbots

      Tools like Tidio offer free tiers that let you:
      - Answer common questions automatically
      - Capture lead information 24/7
      - Route complex inquiries to humans
      - Qualify leads before they reach sales

      ### 3. Predictive Lead Scoring

      Not all leads are equal. AI can analyze behavior patterns to predict which leads are most likely to convert, helping you:
      - Focus sales time on best prospects
      - Customize follow-up intensity
      - Improve conversion rates

      ### 4. Content Optimization

      AI tools can analyze your existing content and suggest:
      - Better headlines
      - Optimal content length
      - Keywords to include
      - Readability improvements

      ## Free Tip: The Simple Personalization Stack

      You don't need expensive AI software. Start with these free/low-cost tools:

      1. Google Analytics 4—Track visitor behavior
      2. Tidio (free tier)—AI chatbot for engagement
      3. ChatGPT—Content creation assistance
      4. URL parameters—Custom landing experiences

      This combination gives you personalization capabilities that cost enterprise companies thousands just a few years ago.

      ## What AI Can't Do

      Be realistic about limitations:
      - AI can't replace human creativity and strategy
      - AI-generated content needs human review
      - AI predictions are probabilities, not certainties
      - AI doesn't understand context the way humans do

      Use AI to enhance human capabilities, not replace them.

      ## Getting Started with AI Marketing

      ### Phase 1: Foundation (Week 1-2)
      - Set up analytics to understand current behavior
      - Implement a simple chatbot on your website
      - Use AI to help draft your next email sequence

      ### Phase 2: Personalization (Week 3-4)
      - Create URL-parameter based landing pages
      - Set up behavior-based email triggers
      - Test personalized vs. generic content

      ### Phase 3: Optimization (Ongoing)
      - Use AI insights to refine targeting
      - Test AI-suggested improvements
      - Measure and iterate

      ## The Human Element

      The best AI marketing strategy combines machine efficiency with human insight. AI handles the repetitive, data-intensive tasks. Humans provide strategy, creativity, and judgment.

      Think of AI as a very capable assistant. It can do a lot, but it still needs direction. The businesses winning with AI aren't fully automated—they're strategically augmented.

      ## Your Next Step

      Pick one AI application from this article and implement it this week. Start small, measure results, and expand from there. The businesses that learn to leverage AI effectively now will have a significant advantage as these tools continue to improve.
    `
  }
];

export default function ResourcesPage() {
  const [expandedArticle, setExpandedArticle] = useState<string | null>('lead-funnel');

  return (
    <main className="pt-20">
      <section className="section-padding">
        <div className="max-w-7xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="max-w-3xl mb-12"
          >
            <h1 className="heading-xl mb-6">Growth Resources & Insights</h1>
            <p className="body-lg">
              Free guides, strategies, and actionable insights to help you generate more leads and grow your business. No fluff.just practical advice you can implement today.
            </p>
          </motion.div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2 space-y-6">
              {articles.map((article) => (
                <AnimatedSection key={article.id}>
                  <div
                    id={article.id}
                    className="card scroll-mt-24"
                  >
                    <button
                      onClick={() =>
                        setExpandedArticle(
                          expandedArticle === article.id ? null : article.id
                        )
                      }
                      className="w-full text-left"
                    >
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <div className="flex items-center gap-3 mb-2">
                            <span className="text-xs text-[#2E7D32] font-medium">
                              {article.readTime}
                            </span>
                            <span className="text-xs text-gray-400">•</span>
                            <span className="text-xs text-gray-500">
                              Free Resource
                            </span>
                          </div>
                          <h2 className="heading-sm mb-2 text-[#121212] hover:text-[#2E7D32] transition-colors">
                            {article.title}
                          </h2>
                          <p className="text-gray-600">{article.excerpt}</p>
                        </div>
                        <div className="ml-4 flex-shrink-0">
                          {expandedArticle === article.id ? (
                            <ChevronUp className="w-6 h-6 text-gray-400" />
                          ) : (
                            <ChevronDown className="w-6 h-6 text-gray-400" />
                          )}
                        </div>
                      </div>
                    </button>

                    {expandedArticle === article.id && (
                      <motion.div
                        initial={{ opacity: 0, height: 0 }}
                        animate={{ opacity: 1, height: 'auto' }}
                        exit={{ opacity: 0, height: 0 }}
                        className="mt-6 pt-6 border-t border-gray-200"
                      >
                        <div className="prose prose-gray max-w-none">
                          {article.content.split('\n\n').map((paragraph, index) => {
                            if (paragraph.startsWith('## ')) {
                              return (
                                <h3 key={index} className="heading-sm mt-8 mb-4">
                                  {paragraph.replace('## ', '')}
                                </h3>
                              );
                            }
                            if (paragraph.startsWith('### ')) {
                              return (
                                <h4 key={index} className="text-lg font-semibold mt-6 mb-3">
                                  {paragraph.replace('### ', '')}
                                </h4>
                              );
                            }
                            if (paragraph.startsWith('- ')) {
                              const items = paragraph.split('\n').filter(Boolean);
                              return (
                                <ul key={index} className="space-y-2 my-4">
                                  {items.map((item, i) => (
                                    <li key={i} className="flex items-start">
                                      <CheckCircle className="w-5 h-5 text-[#2E7D32] mr-3 mt-0.5 flex-shrink-0" />
                                      <span className="text-gray-600">
                                        {item.replace('- ', '')}
                                      </span>
                                    </li>
                                  ))}
                                </ul>
                              );
                            }
                            if (paragraph.trim()) {
                              return (
                                <p key={index} className="text-gray-700 leading-relaxed mb-4">
                                  {paragraph.trim()}
                                </p>
                              );
                            }
                            return null;
                          })}
                        </div>
                      </motion.div>
                    )}
                  </div>
                </AnimatedSection>
              ))}
            </div>

            <div className="lg:col-span-1">
              <div className="sticky top-24 space-y-6">
                <AnimatedSection>
                  <div className="card">
                    <div className="flex items-center mb-4">
                      <Lightbulb className="w-6 h-6 text-[#2E7D32] mr-3" />
                      <h3 className="text-lg font-semibold">Quick Links</h3>
                    </div>
                    <ul className="space-y-3">
                      {articles.map((article) => (
                        <li key={article.id}>
                          <a
                            href={`#${article.id}`}
                            onClick={() => setExpandedArticle(article.id)}
                            className="text-sm text-gray-600 hover:text-[#2E7D32] transition-colors flex items-center"
                          >
                            <ArrowRight className="w-4 h-4 mr-2" />
                            {article.title.split(':')[0]}
                          </a>
                        </li>
                      ))}
                    </ul>
                  </div>
                </AnimatedSection>

                <AnimatedSection delay={0.2}>
                  <div className="card border-2 border-[#2E7D32]">
                    <h3 className="text-lg font-semibold mb-4">
                      Want Personalized Advice?
                    </h3>
                    <p className="text-gray-600 text-sm mb-4">
                      Get a free growth audit tailored to your specific business and industry.
                    </p>
                    <a
                      href="/contact"
                      className="btn-primary w-full flex items-center justify-center text-sm"
                    >
                      Book Free Audit
                      <ArrowRight className="w-4 h-4 ml-2" />
                    </a>
                  </div>
                </AnimatedSection>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="section-padding bg-white">
        <div className="max-w-3xl mx-auto">
          <AnimatedSection className="text-center mb-10">
            <h2 className="heading-lg mb-4">Get More Insights Delivered</h2>
            <p className="body-lg">
              Join our newsletter for weekly growth tips, case studies, and actionable strategies.
            </p>
          </AnimatedSection>

          <AnimatedSection>
            <div className="card">
              <LeadForm source="resources_page" compact />
            </div>
          </AnimatedSection>
        </div>
      </section>
    </main>
  );
}
