import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import {
  Users,
  TrendingUp,
  Calendar,
  Download,
  Trash2,
  Eye,
  LogOut,
  RefreshCw,
  X,
  Settings,
  Lock
} from 'lucide-react';
import { getLeads, getLeadStats, deleteLead, updateAdminPassword, Lead, supabase } from '../lib/supabase';

export default function AdminDashboardPage() {
  const navigate = useNavigate();
  const [leads, setLeads] = useState<Lead[]>([]);
  const [stats, setStats] = useState({ total: 0, thisMonth: 0, byType: {} as Record<string, number> });
  const [isLoading, setIsLoading] = useState(true);
  const [selectedLead, setSelectedLead] = useState<Lead | null>(null);
  const [showSettings, setShowSettings] = useState(false);
  const [newPassword, setNewPassword] = useState('');
  const [passwordMessage, setPasswordMessage] = useState('');
  const [socialLinks, setSocialLinks] = useState({
    instagram: '',
    linkedin: '',
    twitter: '',
    facebook: ''
  });
  const [socialMessage, setSocialMessage] = useState('');

  useEffect(() => {
    const isAuth = sessionStorage.getItem('adminAuth');
    if (!isAuth) {
      navigate('/admin');
      return;
    }
    loadData();
  }, [navigate]);

  useEffect(() => {
    if (showSettings) {
      loadSocialLinks();
    }
  }, [showSettings]);

  const loadData = async () => {
    setIsLoading(true);
    const [leadsData, statsData] = await Promise.all([getLeads(), getLeadStats()]);
    setLeads(leadsData);
    setStats(statsData);
    setIsLoading(false);
  };

  const loadSocialLinks = async () => {
    const { data } = await supabase
      .from('settings')
      .select('instagram_url, linkedin_url, twitter_url, facebook_url')
      .single();

    if (data) {
      setSocialLinks({
        instagram: data.instagram_url || '',
        linkedin: data.linkedin_url || '',
        twitter: data.twitter_url || '',
        facebook: data.facebook_url || ''
      });
    }
  };

  const handleSocialLinksUpdate = async () => {
    const { error } = await supabase
      .from('settings')
      .update({
        instagram_url: socialLinks.instagram,
        linkedin_url: socialLinks.linkedin,
        twitter_url: socialLinks.twitter,
        facebook_url: socialLinks.facebook,
        updated_at: new Date().toISOString()
      })
      .eq('id', (await supabase.from('settings').select('id').single()).data?.id);

    if (!error) {
      setSocialMessage('Social links updated successfully');
      setTimeout(() => setSocialMessage(''), 3000);
    } else {
      setSocialMessage('Failed to update social links');
    }
  };

  const handleLogout = () => {
    sessionStorage.removeItem('adminAuth');
    sessionStorage.removeItem('adminUser');
    navigate('/admin');
  };

  const handleDelete = async (id: string) => {
    if (window.confirm('Are you sure you want to delete this lead?')) {
      await deleteLead(id);
      loadData();
    }
  };

  const handleExportCSV = () => {
    const headers = ['Name', 'Email', 'Phone', 'Business Type', 'Website', 'Pain Point', 'Source', 'Date'];
    const csvContent = [
      headers.join(','),
      ...leads.map((lead) =>
        [
          lead.name,
          lead.email,
          lead.phone || '',
          lead.business_type,
          lead.website_url || '',
          `"${(lead.pain_point || '').replace(/"/g, '""')}"`,
          lead.source || '',
          new Date(lead.created_at || '').toLocaleDateString()
        ].join(',')
      )
    ].join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `cgs-leads-${new Date().toISOString().split('T')[0]}.csv`;
    a.click();
    window.URL.revokeObjectURL(url);
  };

  const handlePasswordChange = async () => {
    if (newPassword.length < 6) {
      setPasswordMessage('Password must be at least 6 characters');
      return;
    }
    const adminUser = sessionStorage.getItem('adminUser') || 'admin';
    const success = await updateAdminPassword(adminUser, newPassword);
    if (success) {
      setPasswordMessage('Password updated successfully');
      setNewPassword('');
      setTimeout(() => setPasswordMessage(''), 3000);
    } else {
      setPasswordMessage('Failed to update password');
    }
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-GB', {
      day: 'numeric',
      month: 'short',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const businessTypeLabels: Record<string, string> = {
    coach: 'Coach / Consultant',
    advisor: 'Financial Advisor',
    gym: 'Gym / Fitness',
    builder: 'Builder / Contractor',
    roofer: 'Roofing',
    dentist: 'Dental',
    other: 'Other'
  };

  return (
    <main className="min-h-screen bg-[#F5F5F5]">
      <header className="bg-white border-b border-gray-200 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <img
              src="/img_8040.jpeg"
              alt="CGS Logo"
              className="h-10 w-auto"
            />
            <span className="font-semibold text-lg">Admin Dashboard</span>
          </div>
          <div className="flex items-center space-x-4">
            <button
              onClick={() => setShowSettings(true)}
              className="p-2 text-gray-600 hover:text-[#121212] transition-colors"
              title="Settings"
            >
              <Settings className="w-5 h-5" />
            </button>
            <button
              onClick={handleLogout}
              className="flex items-center text-gray-600 hover:text-[#121212] transition-colors"
            >
              <LogOut className="w-5 h-5 mr-2" />
              Logout
            </button>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-6 py-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0 }}
            className="card"
          >
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-500 mb-1">Total Leads</p>
                <p className="text-3xl font-bold text-[#121212]">{stats.total}</p>
              </div>
              <div className="w-12 h-12 bg-[#2E7D32]/10 rounded-xl flex items-center justify-center">
                <Users className="w-6 h-6 text-[#2E7D32]" />
              </div>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="card"
          >
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-500 mb-1">This Month</p>
                <p className="text-3xl font-bold text-[#121212]">{stats.thisMonth}</p>
              </div>
              <div className="w-12 h-12 bg-[#1976D2]/10 rounded-xl flex items-center justify-center">
                <Calendar className="w-6 h-6 text-[#1976D2]" />
              </div>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="card"
          >
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-500 mb-1">Conversion Rate</p>
                <p className="text-3xl font-bold text-[#121212]">N/A</p>
              </div>
              <div className="w-12 h-12 bg-[#2E7D32]/10 rounded-xl flex items-center justify-center">
                <TrendingUp className="w-6 h-6 text-[#2E7D32]" />
              </div>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className="card"
          >
            <p className="text-sm text-gray-500 mb-3">By Business Type</p>
            <div className="space-y-2">
              {Object.entries(stats.byType).slice(0, 3).map(([type, count]) => (
                <div key={type} className="flex items-center justify-between text-sm">
                  <span className="text-gray-600">{businessTypeLabels[type] || type}</span>
                  <span className="font-medium">{count}</span>
                </div>
              ))}
            </div>
          </motion.div>
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="card"
        >
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl font-semibold">All Leads</h2>
            <div className="flex items-center space-x-3">
              <button
                onClick={loadData}
                disabled={isLoading}
                className="flex items-center text-gray-600 hover:text-[#121212] transition-colors text-sm"
              >
                <RefreshCw className={`w-4 h-4 mr-2 ${isLoading ? 'animate-spin' : ''}`} />
                Refresh
              </button>
              <button
                onClick={handleExportCSV}
                className="btn-primary text-sm flex items-center"
              >
                <Download className="w-4 h-4 mr-2" />
                Export CSV
              </button>
            </div>
          </div>

          {isLoading ? (
            <div className="text-center py-12">
              <RefreshCw className="w-8 h-8 animate-spin text-gray-400 mx-auto" />
              <p className="text-gray-500 mt-4">Loading leads...</p>
            </div>
          ) : leads.length === 0 ? (
            <div className="text-center py-12">
              <Users className="w-12 h-12 text-gray-300 mx-auto mb-4" />
              <p className="text-gray-500">No leads yet. They'll appear here when submitted.</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-gray-200">
                    <th className="text-left py-3 px-4 text-sm font-medium text-gray-500">Name</th>
                    <th className="text-left py-3 px-4 text-sm font-medium text-gray-500">Email</th>
                    <th className="text-left py-3 px-4 text-sm font-medium text-gray-500">Business</th>
                    <th className="text-left py-3 px-4 text-sm font-medium text-gray-500">Source</th>
                    <th className="text-left py-3 px-4 text-sm font-medium text-gray-500">Date</th>
                    <th className="text-right py-3 px-4 text-sm font-medium text-gray-500">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {leads.map((lead) => (
                    <tr key={lead.id} className="border-b border-gray-100 hover:bg-gray-50">
                      <td className="py-4 px-4">
                        <p className="font-medium text-[#121212]">{lead.name}</p>
                        {lead.phone && (
                          <p className="text-sm text-gray-500">{lead.phone}</p>
                        )}
                      </td>
                      <td className="py-4 px-4">
                        <a href={`mailto:${lead.email}`} className="link-blue text-sm">
                          {lead.email}
                        </a>
                      </td>
                      <td className="py-4 px-4">
                        <span className="inline-block px-2 py-1 bg-gray-100 text-gray-700 text-xs rounded-full">
                          {businessTypeLabels[lead.business_type] || lead.business_type}
                        </span>
                      </td>
                      <td className="py-4 px-4 text-sm text-gray-600">
                        {lead.source || '-'}
                      </td>
                      <td className="py-4 px-4 text-sm text-gray-600">
                        {lead.created_at ? formatDate(lead.created_at) : '-'}
                      </td>
                      <td className="py-4 px-4 text-right">
                        <div className="flex items-center justify-end space-x-2">
                          <button
                            onClick={() => setSelectedLead(lead)}
                            className="p-2 text-gray-400 hover:text-[#1976D2] transition-colors"
                            title="View details"
                          >
                            <Eye className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => lead.id && handleDelete(lead.id)}
                            className="p-2 text-gray-400 hover:text-red-500 transition-colors"
                            title="Delete lead"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </motion.div>
      </div>

      {selectedLead && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50">
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="bg-white rounded-2xl max-w-lg w-full p-6 relative max-h-[90vh] overflow-y-auto"
          >
            <button
              onClick={() => setSelectedLead(null)}
              className="absolute top-4 right-4 text-gray-400 hover:text-gray-600"
            >
              <X className="w-5 h-5" />
            </button>

            <h3 className="text-xl font-semibold mb-6">Lead Details</h3>

            <div className="space-y-4">
              <div>
                <label className="text-sm text-gray-500">Name</label>
                <p className="font-medium">{selectedLead.name}</p>
              </div>
              <div>
                <label className="text-sm text-gray-500">Email</label>
                <p>
                  <a href={`mailto:${selectedLead.email}`} className="link-blue">
                    {selectedLead.email}
                  </a>
                </p>
              </div>
              {selectedLead.phone && (
                <div>
                  <label className="text-sm text-gray-500">Phone</label>
                  <p>{selectedLead.phone}</p>
                </div>
              )}
              <div>
                <label className="text-sm text-gray-500">Business Type</label>
                <p>{businessTypeLabels[selectedLead.business_type] || selectedLead.business_type}</p>
              </div>
              {selectedLead.website_url && (
                <div>
                  <label className="text-sm text-gray-500">Website</label>
                  <p>
                    <a
                      href={selectedLead.website_url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="link-blue"
                    >
                      {selectedLead.website_url}
                    </a>
                  </p>
                </div>
              )}
              {selectedLead.pain_point && (
                <div>
                  <label className="text-sm text-gray-500">Pain Point</label>
                  <p className="text-gray-700 bg-gray-50 p-3 rounded-lg">
                    {selectedLead.pain_point}
                  </p>
                </div>
              )}
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-sm text-gray-500">Source</label>
                  <p>{selectedLead.source || '-'}</p>
                </div>
                <div>
                  <label className="text-sm text-gray-500">Niche Param</label>
                  <p>{selectedLead.niche_param || '-'}</p>
                </div>
              </div>
              <div>
                <label className="text-sm text-gray-500">Submitted</label>
                <p>{selectedLead.created_at ? formatDate(selectedLead.created_at) : '-'}</p>
              </div>
            </div>

            <div className="mt-6 pt-6 border-t border-gray-200 flex justify-end space-x-3">
              <a
                href={`mailto:${selectedLead.email}`}
                className="btn-primary text-sm"
              >
                Send Email
              </a>
              <button
                onClick={() => setSelectedLead(null)}
                className="btn-secondary text-sm"
              >
                Close
              </button>
            </div>
          </motion.div>
        </div>
      )}

      {showSettings && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50">
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="bg-white rounded-2xl max-w-md w-full p-6 relative"
          >
            <button
              onClick={() => setShowSettings(false)}
              className="absolute top-4 right-4 text-gray-400 hover:text-gray-600"
            >
              <X className="w-5 h-5" />
            </button>

            <h3 className="text-xl font-semibold mb-6">Settings</h3>

            <div className="space-y-6 max-h-[70vh] overflow-y-auto">
              <div className="space-y-4">
                <h4 className="font-medium text-gray-900">Change Password</h4>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    New Password
                  </label>
                  <div className="relative">
                    <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                    <input
                      type="password"
                      value={newPassword}
                      onChange={(e) => setNewPassword(e.target.value)}
                      className="input-field pl-10"
                      placeholder="Enter new password"
                    />
                  </div>
                </div>

                {passwordMessage && (
                  <p className={`text-sm ${passwordMessage.includes('success') ? 'text-green-600' : 'text-red-600'}`}>
                    {passwordMessage}
                  </p>
                )}

                <button
                  onClick={handlePasswordChange}
                  className="btn-primary w-full"
                >
                  Update Password
                </button>
              </div>

              <div className="border-t border-gray-200 pt-6 space-y-4">
                <h4 className="font-medium text-gray-900">Social Media Links</h4>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Instagram URL
                  </label>
                  <input
                    type="url"
                    value={socialLinks.instagram}
                    onChange={(e) => setSocialLinks({ ...socialLinks, instagram: e.target.value })}
                    className="input-field"
                    placeholder="https://instagram.com/cgsleads"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    LinkedIn URL
                  </label>
                  <input
                    type="url"
                    value={socialLinks.linkedin}
                    onChange={(e) => setSocialLinks({ ...socialLinks, linkedin: e.target.value })}
                    className="input-field"
                    placeholder="https://linkedin.com/company/..."
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Twitter URL
                  </label>
                  <input
                    type="url"
                    value={socialLinks.twitter}
                    onChange={(e) => setSocialLinks({ ...socialLinks, twitter: e.target.value })}
                    className="input-field"
                    placeholder="https://twitter.com/..."
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Facebook URL
                  </label>
                  <input
                    type="url"
                    value={socialLinks.facebook}
                    onChange={(e) => setSocialLinks({ ...socialLinks, facebook: e.target.value })}
                    className="input-field"
                    placeholder="https://facebook.com/..."
                  />
                </div>

                {socialMessage && (
                  <p className={`text-sm ${socialMessage.includes('success') ? 'text-green-600' : 'text-red-600'}`}>
                    {socialMessage}
                  </p>
                )}

                <button
                  onClick={handleSocialLinksUpdate}
                  className="btn-primary w-full"
                >
                  Update Social Links
                </button>
              </div>
            </div>
          </motion.div>
        </div>
      )}
    </main>
  );
}
