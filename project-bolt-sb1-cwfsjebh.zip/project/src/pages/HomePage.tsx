import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import {
  Search,
  Target,
  Wrench,
  TrendingUp,
  Globe,
  Layers,
  Megaphone,
  MapPin,
  Mail,
  Bot,
  ArrowRight,
  Download,
  CheckCircle
} from 'lucide-react';
import AnimatedSection from '../components/AnimatedSection';
import ServiceCard from '../components/ServiceCard';
import CaseStudyCard from '../components/CaseStudyCard';
import LeadForm from '../components/LeadForm';
import { usePersonalization } from '../context/PersonalizationContext';

const steps = [
  {
    icon: Search,
    title: 'Diagnose Your Business',
    description: 'We study your model, products, and services to understand your unique value.',
    image: 'https://images.pexels.com/photos/3184292/pexels-photo-3184292.jpeg?auto=compress&cs=tinysrgb&w=800',
    bullets: [
      'Deep dive into your business model and revenue streams',
      'Analyze your current marketing efforts and results',
      'Identify opportunities competitors are missing'
    ]
  },
  {
    icon: Target,
    title: 'Identify Pain Points & Ideal Customers',
    description: 'Find what\'s holding you back and who your best customers are.',
    image: 'https://images.pexels.com/photos/3183197/pexels-photo-3183197.jpeg?auto=compress&cs=tinysrgb&w=800',
    bullets: [
      'Map your ideal customer profile with precision',
      'Uncover hidden bottlenecks in your sales process',
      'Define messaging that resonates with buyers'
    ]
  },
  {
    icon: Wrench,
    title: 'Build Your Custom System',
    description: 'Create smart websites, funnels, ads, and automation tailored to your business.',
    image: 'https://images.pexels.com/photos/3183150/pexels-photo-3183150.jpeg?auto=compress&cs=tinysrgb&w=800',
    bullets: [
      'Design high-converting landing pages and funnels',
      'Set up targeted ad campaigns across platforms',
      'Implement automation that works 24/7'
    ]
  },
  {
    icon: TrendingUp,
    title: 'Deliver ROI',
    description: 'Get 20-50 leads per month with measurable growth, or your money back.',
    image: 'https://images.pexels.com/photos/3184465/pexels-photo-3184465.jpeg?auto=compress&cs=tinysrgb&w=800',
    bullets: [
      'Track every lead from first click to conversion',
      'Monthly reporting with clear metrics',
      'Continuous optimization based on data'
    ]
  }
];

const services = [
  {
    icon: Globe,
    title: 'Smart Website Upgrades',
    description: 'Add lead capture features like forms and chatbots to convert visitors 24/7. Your website becomes a lead-generating machine, not just a digital brochure.'
  },
  {
    icon: Layers,
    title: 'High-Conversion Landing Pages & Funnels',
    description: 'Custom pages that guide leads to sign up or book. Every element is designed to move visitors toward taking action.'
  },
  {
    icon: Megaphone,
    title: 'Targeted Ads',
    description: 'Facebook, Instagram, Google ads to reach ready-to-buy customers. We target the right people at the right time with the right message.'
  },
  {
    icon: MapPin,
    title: 'Local SEO & Optimization',
    description: 'Rank on Google for local searches and get free organic traffic. Dominate local search results and capture customers actively looking for your services.'
  },
  {
    icon: Mail,
    title: 'Email & Automation',
    description: 'Nurture leads with sequences that turn interest into sales. Automated follow-ups ensure no lead falls through the cracks.'
  },
  {
    icon: Bot,
    title: 'AI Campaigns & Tracking',
    description: 'Personalized ads and behavior analysis for max ROI. Smart technology that learns and improves your campaigns over time.'
  }
];

const caseStudies = [
  {
    title: 'Financial Advisor: 28 Leads in 18 Days',
    category: 'Finance',
    metrics: { leads: '28', conversions: '10', revenue: '£12K' },
    quote: 'Professional, data-driven, and they actually delivered. My calendar is now full of qualified consultations.',
    image: 'https://images.pexels.com/photos/6801648/pexels-photo-6801648.jpeg?auto=compress&cs=tinysrgb&w=800'
  },
  {
    title: 'Business Coach: 45 Leads in 21 Days',
    category: 'Coaching',
    metrics: { leads: '45', conversions: '12', revenue: '$18K' },
    quote: 'CGS built a system that brought me qualified mentorship applicants on autopilot. The ROI was incredible.',
    image: 'https://images.pexels.com/photos/7688336/pexels-photo-7688336.jpeg?auto=compress&cs=tinysrgb&w=800'
  },
  {
    title: 'Fitness Studio: 35 Leads in 14 Days',
    category: 'Fitness',
    metrics: { leads: '35', conversions: '15', revenue: '£4.5K/mo' },
    quote: 'We went from empty classes to a waitlist. The local SEO and targeted ads completely transformed our business.',
    image: 'https://images.pexels.com/photos/703016/pexels-photo-703016.jpeg?auto=compress&cs=tinysrgb&w=800'
  }
];

export default function HomePage() {
  const { content } = usePersonalization();

  return (
    <main>
      <section className="min-h-screen flex items-center section-padding pt-32 relative overflow-hidden">
        <div className="absolute inset-0 z-0">
          <video
            autoPlay
            loop
            muted
            playsInline
            className="w-full h-full object-cover"
          >
            <source src="https://cdn.pixabay.com/video/2022/09/27/133092-755926550_large.mp4" type="video/mp4" />
          </video>
          <div className="absolute inset-0 bg-gradient-to-r from-[#FAFAFA]/95 via-[#FAFAFA]/90 to-[#FAFAFA]/85"></div>
        </div>
        <div className="max-w-7xl mx-auto w-full relative z-10">
          <div className="max-w-3xl">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
            >
              <h1 className="heading-xl mb-6 text-[#121212]">
                {content.headline}
              </h1>
              <p className="text-xl md:text-2xl text-[#2E7D32] font-medium mb-6">
                {content.subheadline}
              </p>
              <p className="body-lg mb-8 max-w-2xl">
                At CGS, we solve inconsistent customer flow for ambitious service and online businesses. Our systems deliver qualified leads on autopilot, turning prospects into high-value customers predictably. <span className="font-semibold">Limited to 5 clients per month.</span>
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Link to="/contact" className="btn-primary inline-flex items-center justify-center">
                  {content.cta}
                  <ArrowRight className="ml-2 w-5 h-5" />
                </Link>
                <Link to="/case-studies" className="btn-secondary inline-flex items-center justify-center">
                  See Our Results
                </Link>
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.4, duration: 0.6 }}
              className="mt-12 flex flex-wrap gap-6"
            >
              {content.painPoints.map((point, i) => (
                <div key={i} className="flex items-center text-gray-600">
                  <CheckCircle className="w-5 h-5 text-[#2E7D32] mr-2" />
                  <span className="text-sm">We fix: {point}</span>
                </div>
              ))}
            </motion.div>
          </div>
        </div>
      </section>

      <section className="section-padding bg-white">
        <div className="max-w-7xl mx-auto">
          <AnimatedSection className="text-center mb-16">
            <h2 className="heading-lg mb-4">How We Transform Your Business</h2>
            <p className="body-lg max-w-2xl mx-auto">
              Our proven 4-step process takes you from inconsistent leads to predictable growth
            </p>
          </AnimatedSection>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {steps.map((step, index) => (
              <AnimatedSection key={index} delay={index * 0.1}>
                <div className="relative">
                  <div className="absolute -top-4 -left-4 w-8 h-8 bg-[#2E7D32] text-white rounded-full flex items-center justify-center text-sm font-bold z-10">
                    {index + 1}
                  </div>
                  <div className="card h-full overflow-hidden p-0">
                    <div className="relative h-48 overflow-hidden">
                      <img
                        src={step.image}
                        alt={step.title}
                        className="w-full h-full object-cover"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent"></div>
                      <div className="absolute bottom-4 left-4">
                        <step.icon className="w-10 h-10 text-white drop-shadow-lg" />
                      </div>
                    </div>
                    <div className="p-8">
                      <h3 className="text-lg font-semibold mb-3">{step.title}</h3>
                      <p className="text-gray-600 text-sm mb-4">{step.description}</p>
                      <ul className="space-y-2">
                        {step.bullets.map((bullet, i) => (
                          <li key={i} className="flex items-start text-sm text-gray-500">
                            <CheckCircle className="w-4 h-4 text-[#2E7D32] mr-2 mt-0.5 flex-shrink-0" />
                            {bullet}
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>
                </div>
              </AnimatedSection>
            ))}
          </div>
        </div>
      </section>

      <section className="section-padding">
        <div className="max-w-7xl mx-auto">
          <AnimatedSection className="text-center mb-16">
            <h2 className="heading-lg mb-4">Our Proven Systems</h2>
            <p className="body-lg max-w-2xl mx-auto">
              We combine multiple channels into one cohesive system that generates leads around the clock
            </p>
          </AnimatedSection>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {services.map((service, index) => (
              <ServiceCard
                key={index}
                icon={service.icon}
                title={service.title}
                description={service.description}
                index={index}
              />
            ))}
          </div>
        </div>
      </section>

      <section className="section-padding bg-white">
        <div className="max-w-7xl mx-auto">
          <AnimatedSection className="text-center mb-16">
            <h2 className="heading-lg mb-4">Real Results</h2>
            <p className="body-lg max-w-2xl mx-auto">
              See how we've helped businesses like yours achieve predictable growth
            </p>
          </AnimatedSection>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {caseStudies.map((study, index) => (
              <CaseStudyCard key={index} {...study} index={index} />
            ))}
          </div>

          <AnimatedSection className="text-center mt-12">
            <Link to="/case-studies" className="btn-secondary inline-flex items-center">
              View All Case Studies
              <ArrowRight className="ml-2 w-5 h-5" />
            </Link>
          </AnimatedSection>
        </div>
      </section>

      <section className="section-padding">
        <div className="max-w-7xl mx-auto">
          <div className="card max-w-4xl mx-auto">
            <AnimatedSection className="text-center mb-8">
              <h2 className="heading-lg mb-4">Get Free Growth Resources</h2>
              <p className="body-lg">
                Download our comprehensive guides to start improving your lead generation today. No strings attached.
              </p>
            </AnimatedSection>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Link
                to="/resources#lead-funnel"
                className="flex items-center p-4 border border-gray-200 rounded-lg hover:border-[#2E7D32] transition-colors group"
              >
                <div className="w-12 h-12 bg-[#2E7D32]/10 rounded-lg flex items-center justify-center mr-4 group-hover:bg-[#2E7D32]/20 transition-colors">
                  <Download className="w-6 h-6 text-[#2E7D32]" />
                </div>
                <div>
                  <h4 className="font-semibold text-[#121212]">Lead Funnel Guide</h4>
                  <p className="text-sm text-gray-500">Build a funnel that converts 24/7</p>
                </div>
              </Link>

              <Link
                to="/resources#email-automation"
                className="flex items-center p-4 border border-gray-200 rounded-lg hover:border-[#2E7D32] transition-colors group"
              >
                <div className="w-12 h-12 bg-[#2E7D32]/10 rounded-lg flex items-center justify-center mr-4 group-hover:bg-[#2E7D32]/20 transition-colors">
                  <Download className="w-6 h-6 text-[#2E7D32]" />
                </div>
                <div>
                  <h4 className="font-semibold text-[#121212]">Email Automation Blueprint</h4>
                  <p className="text-sm text-gray-500">Turn leads into customers automatically</p>
                </div>
              </Link>
            </div>

            <AnimatedSection className="text-center mt-8">
              <Link to="/resources" className="link-blue font-medium">
                Browse All Free Resources
              </Link>
            </AnimatedSection>
          </div>
        </div>
      </section>

      <section className="section-padding bg-[#121212]" id="waiting-list">
        <div className="max-w-3xl mx-auto">
          <AnimatedSection className="text-center mb-10">
            <h2 className="heading-lg text-white mb-4">
              Join Our Waiting List
            </h2>
            <p className="text-[#2E7D32] font-medium text-lg mb-2">Only 5 Spots Available Per Month</p>
            <p className="body-lg text-gray-300">
              We limit our client intake to ensure exceptional results for every business we work with. Reserve your spot and get a free growth audit.
            </p>
          </AnimatedSection>

          <AnimatedSection>
            <div className="bg-white rounded-2xl p-8 md:p-10">
              <LeadForm source="homepage_waitlist" />
            </div>
          </AnimatedSection>
        </div>
      </section>
    </main>
  );
}
