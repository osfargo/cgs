import { motion } from 'framer-motion';
import { Mail, Phone, Clock, MapPin, CheckCircle } from 'lucide-react';
import AnimatedSection from '../components/AnimatedSection';
import LeadForm from '../components/LeadForm';

const benefits = [
  'Free growth audit tailored to your business',
  'Custom strategy recommendations',
  'No obligation, just valuable insights',
  'Response within 24 hours'
];

const faqs = [
  {
    question: 'What happens after I submit the form?',
    answer: 'We\'ll review your submission and reach out within 24 hours to schedule a free growth audit call. During this call, we\'ll analyze your current marketing, identify opportunities, and provide actionable recommendations, whether you work with us or not.'
  },
  {
    question: 'How much do your services cost?',
    answer: 'Our pricing is customized based on your specific needs and goals. We don\'t believe in one-size-fits-all packages. During your growth audit, we\'ll discuss options that fit your budget and objectives. Investment typically ranges based on the scope and scale of your business.'
  },
  {
    question: 'Why do you only take 5 clients per month?',
    answer: 'Quality over quantity. By limiting our client intake, we ensure every business gets the attention it deserves. This approach is why we can offer our money-back guarantee. We only take on clients we\'re confident we can help and dedicate the resources needed for exceptional results.'
  },
  {
    question: 'What industries do you work with?',
    answer: 'We specialize in high-ticket professional service businesses including coaches, consultants, financial advisors, and other service-based businesses. We focus on industries where we can deliver the most impactful results through proven systems.'
  },
  {
    question: 'How long does it take to see results?',
    answer: 'Most clients start seeing qualified leads within the first 30 days of launching their campaigns. However, the timeline can vary based on your industry, target market, and current marketing infrastructure. We provide realistic timelines during your growth audit.'
  },
  {
    question: 'Do you require long-term contracts?',
    answer: 'We believe in earning your business every month. While we recommend at least 3-6 months to see optimal results from our systems, we don\'t lock you into long-term contracts. Our goal is to deliver such exceptional results that you want to continue working with us.'
  },
  {
    question: 'What makes CGS different from other marketing agencies?',
    answer: 'We focus exclusively on lead generation and customer acquisition, not branding or awareness. We guarantee 20-50 qualified leads per month or your money back. We limit our client roster to 5 new clients per month to ensure exceptional service. Plus, every system we build is custom-tailored to your specific business model and ideal customer profile.'
  }
];

export default function ContactPage() {
  return (
    <main className="pt-20">
      <section className="section-padding">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
            >
              <h1 className="heading-xl mb-6">Let's Grow Your Business</h1>
              <p className="body-lg mb-8">
                Ready to transform inconsistent leads into predictable growth? Fill out the form and our team will create a custom growth audit for your business.
              </p>

              <div className="space-y-4 mb-8">
                {benefits.map((benefit, index) => (
                  <div key={index} className="flex items-center">
                    <CheckCircle className="w-5 h-5 text-[#2E7D32] mr-3 flex-shrink-0" />
                    <span className="text-gray-700">{benefit}</span>
                  </div>
                ))}
              </div>

              <div className="card bg-gray-50 mb-8">
                <h3 className="font-semibold mb-4">Get in Touch</h3>
                <div className="space-y-4">
                  <a
                    href="mailto:info@cgsleads.com"
                    className="flex items-center text-gray-600 hover:text-[#2E7D32] transition-colors"
                  >
                    <Mail className="w-5 h-5 mr-3" />
                    info@cgsleads.com
                  </a>
                  <a
                    href="mailto:cgs.clientsacquisitions@gmail.com"
                    className="flex items-center text-gray-600 hover:text-[#2E7D32] transition-colors"
                  >
                    <Mail className="w-5 h-5 mr-3" />
                    cgs.clientsacquisitions@gmail.com
                  </a>
                  <a
                    href="tel:+447436101043"
                    className="flex items-center text-gray-600 hover:text-[#2E7D32] transition-colors"
                  >
                    <Phone className="w-5 h-5 mr-3" />
                    +44 743 610 1043
                  </a>
                  <div className="flex items-center text-gray-600">
                    <Clock className="w-5 h-5 mr-3" />
                    Mon-Fri: 9AM - 6PM GMT
                  </div>
                  <div className="flex items-center text-gray-600">
                    <MapPin className="w-5 h-5 mr-3" />
                    London, United Kingdom
                  </div>
                </div>
              </div>

              <div className="bg-[#2E7D32]/5 border-l-4 border-[#2E7D32] p-6 rounded-r-lg">
                <p className="text-gray-700 italic">
                  "We only accept 5 new clients per month to ensure exceptional results. Spots fill quickly, so don't wait to secure your growth audit."
                </p>
              </div>
            </motion.div>

            <AnimatedSection delay={0.2}>
              <div className="card">
                <h2 className="heading-sm mb-6">Request Your Free Growth Audit</h2>
                <LeadForm source="contact_page" />
              </div>
            </AnimatedSection>
          </div>
        </div>
      </section>

      <section className="section-padding bg-white">
        <div className="max-w-3xl mx-auto">
          <AnimatedSection className="text-center mb-12">
            <h2 className="heading-lg mb-4">Frequently Asked Questions</h2>
            <p className="body-md">
              Have questions? We've got answers.
            </p>
          </AnimatedSection>

          <div className="space-y-6">
            {faqs.map((faq, index) => (
              <AnimatedSection key={index} delay={index * 0.1}>
                <div className="card">
                  <h3 className="font-semibold mb-3 text-[#121212]">{faq.question}</h3>
                  <p className="text-gray-600 leading-relaxed">{faq.answer}</p>
                </div>
              </AnimatedSection>
            ))}
          </div>
        </div>
      </section>
    </main>
  );
}
