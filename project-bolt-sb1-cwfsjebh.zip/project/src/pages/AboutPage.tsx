import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import {
  Target,
  Award,
  Users,
  TrendingUp,
  Download,
  CheckCircle,
  ArrowRight
} from 'lucide-react';
import AnimatedSection from '../components/AnimatedSection';
import LeadForm from '../components/LeadForm';

const values = [
  {
    icon: Target,
    title: 'Results-Focused',
    description: 'We measure success by your revenue growth, not vanity metrics. Every strategy we implement is designed to deliver measurable ROI.'
  },
  {
    icon: Award,
    title: 'Selective Partnership',
    description: 'We only take on 5 clients per month. This allows us to give each business the attention it deserves and guarantee results.'
  },
  {
    icon: Users,
    title: 'Deep Understanding',
    description: 'We don\'t use cookie-cutter solutions. Every system we build starts with a deep understanding of your specific business model.'
  },
  {
    icon: TrendingUp,
    title: 'Continuous Optimization',
    description: 'Marketing isn\'t set-and-forget. We continuously analyze, test, and optimize your campaigns to maximize performance.'
  }
];

const pillars = [
  'Business Diagnosis: Understanding your unique model and value proposition',
  'Customer Identification: Finding and targeting your ideal buyers',
  'System Building: Creating automated lead generation infrastructure',
  'Performance Tracking: Measuring and optimizing for continuous improvement',
  'ROI Delivery: Ensuring every dollar spent returns multiple in revenue'
];

export default function AboutPage() {
  return (
    <main className="pt-20">
      <section className="section-padding">
        <div className="max-w-7xl mx-auto">
          <div className="max-w-3xl">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
            >
              <h1 className="heading-xl mb-6">About CGS</h1>
              <p className="body-lg mb-8">
                Client Growth Systems is a selective agency focused on predictable customer acquisition for high-ticket service businesses.
              </p>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2, duration: 0.6 }}
              className="space-y-6 text-gray-700"
            >
              <p className="text-lg leading-relaxed">
                We don't chase vanity metrics. We deliver leads that convert to revenue. While other agencies focus on impressions, clicks, and "engagement," we focus on the only metric that matters: qualified leads that become paying customers.
              </p>

              <p className="text-lg leading-relaxed">
                Founded in 2025, Client Growth Systems is built on a simple principle: marketing should be measurable, predictable, and profitable. We specialize in serving coaches, consultants, financial advisors, and other professional service businesses who need a steady flow of high-quality clients.
              </p>

              <p className="text-lg leading-relaxed">
                Our systems work 24/7, combining proven digital marketing strategies with smart automation to create lead generation machines that operate around the clock. We've helped professional service businesses scale predictably by building custom acquisition systems tailored to their specific market and ideal client profile.
              </p>

              <p className="text-lg leading-relaxed">
                We understand that inconsistent customer flow is the biggest challenge for service-based businesses. One month you're overwhelmed, the next you're wondering where the next client will come from. Our systems eliminate this uncertainty by creating predictable, reliable streams of qualified leads.
              </p>

              <div className="bg-[#2E7D32]/5 border-l-4 border-[#2E7D32] p-6 rounded-r-lg my-8">
                <p className="text-xl font-medium text-[#121212] italic">
                  "Predictable Growth Through Smart Systems"
                </p>
                <p className="text-gray-600 mt-2">Our founding principle</p>
              </div>

              <p className="text-lg leading-relaxed">
                We limit ourselves to 5 clients per month because we believe in quality over quantity. This selectivity allows us to deliver exceptional results for every business we partner with, which is why we can offer our money-back guarantee.
              </p>
            </motion.div>
          </div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4, duration: 0.6 }}
            className="mt-16"
          >
            <div className="relative h-96 rounded-2xl overflow-hidden shadow-lg">
              <img
                src="https://images.pexels.com/photos/3184338/pexels-photo-3184338.jpeg?auto=compress&cs=tinysrgb&w=1600"
                alt="Professional business team collaboration"
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/40 to-transparent"></div>
            </div>
          </motion.div>
        </div>
      </section>

      <section className="section-padding bg-white">
        <div className="max-w-7xl mx-auto">
          <AnimatedSection className="text-center mb-16">
            <h2 className="heading-lg mb-4">What Sets Us Apart</h2>
            <p className="body-lg max-w-2xl mx-auto">
              Our values guide everything we do
            </p>
          </AnimatedSection>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {values.map((value, index) => (
              <AnimatedSection key={index} delay={index * 0.1}>
                <div className="card h-full">
                  <div className="flex items-start">
                    <div className="w-12 h-12 bg-[#2E7D32]/10 rounded-xl flex items-center justify-center mr-4 flex-shrink-0">
                      <value.icon className="w-6 h-6 text-[#2E7D32]" />
                    </div>
                    <div>
                      <h3 className="text-xl font-semibold mb-2">{value.title}</h3>
                      <p className="text-gray-600">{value.description}</p>
                    </div>
                  </div>
                </div>
              </AnimatedSection>
            ))}
          </div>
        </div>
      </section>

      <section className="section-padding">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            <AnimatedSection>
              <div className="card bg-[#121212] text-white">
                <div className="flex items-center mb-6">
                  <Download className="w-8 h-8 text-[#2E7D32] mr-4" />
                  <h3 className="text-2xl font-semibold">Free Resource</h3>
                </div>
                <h4 className="text-xl mb-4">The 5 Pillars of Customer Acquisition</h4>
                <p className="text-gray-300 mb-6">
                  Our comprehensive guide breaks down the exact framework we use to generate 20-50 leads per month for our clients. Download it now and start implementing these strategies today.
                </p>
                <ul className="space-y-3 mb-8">
                  {pillars.map((pillar, index) => (
                    <li key={index} className="flex items-start">
                      <CheckCircle className="w-5 h-5 text-[#2E7D32] mr-3 mt-0.5 flex-shrink-0" />
                      <span className="text-gray-200 text-sm">{pillar}</span>
                    </li>
                  ))}
                </ul>
                <Link
                  to="/resources"
                  className="btn-primary inline-flex items-center"
                >
                  Download Free Guide
                  <ArrowRight className="ml-2 w-5 h-5" />
                </Link>
              </div>
            </AnimatedSection>

            <AnimatedSection delay={0.2}>
              <h2 className="heading-lg mb-6">Why Businesses Trust Us</h2>
              <div className="space-y-6">
                <div className="flex items-start">
                  <div className="w-10 h-10 bg-[#2E7D32] rounded-full flex items-center justify-center text-white font-bold mr-4 flex-shrink-0">
                    1
                  </div>
                  <div>
                    <h4 className="font-semibold mb-2">Money-Back Guarantee</h4>
                    <p className="text-gray-600">
                      If we don't deliver 20-50 qualified leads per month, you get your money back. We're that confident in our systems.
                    </p>
                  </div>
                </div>
                <div className="flex items-start">
                  <div className="w-10 h-10 bg-[#2E7D32] rounded-full flex items-center justify-center text-white font-bold mr-4 flex-shrink-0">
                    2
                  </div>
                  <div>
                    <h4 className="font-semibold mb-2">Transparent Reporting</h4>
                    <p className="text-gray-600">
                      You'll see exactly where every lead comes from and how your campaigns are performing. No black boxes.
                    </p>
                  </div>
                </div>
                <div className="flex items-start">
                  <div className="w-10 h-10 bg-[#2E7D32] rounded-full flex items-center justify-center text-white font-bold mr-4 flex-shrink-0">
                    3
                  </div>
                  <div>
                    <h4 className="font-semibold mb-2">Industry Expertise</h4>
                    <p className="text-gray-600">
                      We specialize in professional service businesses: coaches, consultants, financial advisors, and high-ticket service providers. We understand your market and your ideal client.
                    </p>
                  </div>
                </div>
              </div>
            </AnimatedSection>
          </div>
        </div>
      </section>

      <section className="section-padding bg-white">
        <div className="max-w-3xl mx-auto">
          <AnimatedSection className="text-center mb-10">
            <h2 className="heading-lg mb-4">Ready to Grow Predictably?</h2>
            <p className="body-lg">
              Let's discuss how we can help your business achieve consistent, measurable growth.
            </p>
          </AnimatedSection>

          <AnimatedSection>
            <div className="card">
              <LeadForm source="about_page" />
            </div>
          </AnimatedSection>
        </div>
      </section>
    </main>
  );
}
