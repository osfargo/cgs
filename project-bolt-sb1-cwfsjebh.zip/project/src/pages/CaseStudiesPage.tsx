import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import {
  TrendingUp,
  Users,
  DollarSign,
  Calendar,
  Target,
  CheckCircle,
  ArrowRight
} from 'lucide-react';
import AnimatedSection from '../components/AnimatedSection';
import LeadForm from '../components/LeadForm';

const caseStudies = [
  {
    id: 'coaching',
    category: 'Coaching',
    title: 'OnlyFans Agency Coach',
    subtitle: '45 Qualified Leads in 21 Days',
    headline: 'From Struggling to Find Students to 12 New Mentorship Sign-ups at $1,500 Each',
    metrics: {
      leads: '45',
      conversions: '12',
      revenue: '$18,000',
      timeline: '21 days'
    },
    challenge: 'Our client ran a successful coaching program teaching entrepreneurs how to start OnlyFans management agencies. Despite having proven results with past students, they struggled to find qualified applicants. Their previous marketing efforts generated tire-kickers who weren\'t serious about investing in mentorship.',
    solution: 'We built a targeted funnel specifically designed to attract aspiring OF agency owners who were ready to invest in their education. The system combined:',
    systems: [
      'Facebook ads targeting entrepreneurial audiences interested in digital marketing and agency models',
      'A high-converting landing page that pre-qualified prospects through strategic messaging',
      'An email automation sequence that provided value and built trust before the sales call',
      'Behavioral tracking to identify and prioritize the most engaged leads'
    ],
    results: 'Within 21 days, the funnel generated 45 qualified leads: people who met the criteria and had shown genuine interest. Of these, 12 enrolled in the $1,500 mentorship program, generating $18,000 in revenue. The system continues to run, providing a steady stream of applicants each month.',
    quote: {
      text: 'CGS built a system that brought me qualified mentorship applicants on autopilot. Before, I was spending hours on calls with people who weren\'t serious. Now, everyone who books a call is ready to invest. The ROI was incredible.',
      author: 'Agency Coaching Client'
    }
  },
  {
    id: 'gym',
    category: 'Fitness',
    title: 'Local Gym',
    subtitle: '35 Leads in 14 Days',
    headline: 'Converting 15 New Members and Adding £4,500 to Monthly Revenue',
    metrics: {
      leads: '35',
      conversions: '15',
      revenue: '£4,500/mo',
      timeline: '14 days'
    },
    challenge: 'This gym had a great facility and trainers but struggled with inconsistent membership sign-ups. Their marketing was sporadic, posting on social media occasionally and relying heavily on word-of-mouth. Months would go by with barely any new members joining.',
    solution: 'We implemented a comprehensive local customer acquisition system:',
    systems: [
      'Optimized their Google Business Profile for "gym near me" and related local searches',
      'Created targeted Facebook and Instagram ads reaching fitness enthusiasts within a 5-mile radius',
      'Built a landing page offering a free trial that captured visitor information',
      'Website upgrades including a chatbot and strategic lead capture forms'
    ],
    results: 'In just 14 days, the gym received 35 qualified leads: local residents interested in joining. 15 of these converted to paying members, adding £4,500 to their monthly recurring revenue. The local SEO improvements continue to drive free organic traffic.',
    quote: {
      text: 'We went from empty classes to a waitlist for our popular sessions. The local SEO and targeted ads completely transformed our business. We finally have predictable growth.',
      author: 'Gym Owner'
    }
  },
  {
    id: 'advisor',
    category: 'Financial Services',
    title: 'Financial Advisor',
    subtitle: '28 Qualified Leads in 18 Days',
    headline: 'Generating 10 New Clients Worth £12,000 in Fees',
    metrics: {
      leads: '28',
      conversions: '10',
      revenue: '£12,000',
      timeline: '18 days'
    },
    challenge: 'As a financial advisor in a competitive market, our client struggled to differentiate themselves and attract high-net-worth individuals. Their previous marketing efforts resulted in low-quality leads who weren\'t ready to commit to professional financial planning.',
    solution: 'We developed a sophisticated lead generation system that positioned the advisor as an expert:',
    systems: [
      'AI-driven campaigns that personalized messaging based on prospect behavior',
      'Content marketing strategy establishing thought leadership',
      'Behavioral tracking to identify prospects showing buying signals',
      'Email nurture sequences educating prospects about financial planning'
    ],
    results: 'Over 18 days, the system generated 28 qualified leads: individuals who met the minimum asset threshold and showed genuine interest in financial planning. 10 of these became clients, representing £12,000 in initial fees with potential for ongoing advisory relationships.',
    quote: {
      text: 'Professional, data-driven, and they actually delivered. My calendar is now full of qualified consultations with people who are ready to work with an advisor. The quality of leads is exceptional.',
      author: 'Financial Advisor Client'
    }
  }
];

export default function CaseStudiesPage() {
  return (
    <main className="pt-20">
      <section className="section-padding">
        <div className="max-w-7xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="max-w-3xl"
          >
            <h1 className="heading-xl mb-6">Real Client Transformations</h1>
            <p className="body-lg">
              Don't just take our word for it. See exactly how we've helped businesses like yours achieve predictable growth with detailed breakdowns of our process and results.
            </p>
          </motion.div>
        </div>
      </section>

      {caseStudies.map((study, index) => (
        <section
          key={study.id}
          id={study.id}
          className={`section-padding ${index % 2 === 0 ? 'bg-white' : ''}`}
        >
          <div className="max-w-7xl mx-auto">
            <AnimatedSection>
              <div className="flex items-center gap-4 mb-6">
                <span className="px-4 py-1 bg-[#2E7D32]/10 text-[#2E7D32] text-sm font-medium rounded-full">
                  {study.category}
                </span>
                <span className="text-gray-400">|</span>
                <span className="text-gray-600">{study.title}</span>
              </div>

              <h2 className="heading-lg mb-4">{study.headline}</h2>
              <p className="text-xl text-[#2E7D32] font-medium mb-8">{study.subtitle}</p>
            </AnimatedSection>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-12">
              <AnimatedSection delay={0.1}>
                <div className="card text-center">
                  <Users className="w-8 h-8 text-[#1976D2] mx-auto mb-2" />
                  <p className="text-3xl font-bold text-[#121212]">{study.metrics.leads}</p>
                  <p className="text-sm text-gray-500">Qualified Leads</p>
                </div>
              </AnimatedSection>
              <AnimatedSection delay={0.2}>
                <div className="card text-center">
                  <TrendingUp className="w-8 h-8 text-[#2E7D32] mx-auto mb-2" />
                  <p className="text-3xl font-bold text-[#121212]">{study.metrics.conversions}</p>
                  <p className="text-sm text-gray-500">Conversions</p>
                </div>
              </AnimatedSection>
              <AnimatedSection delay={0.3}>
                <div className="card text-center">
                  <DollarSign className="w-8 h-8 text-[#2E7D32] mx-auto mb-2" />
                  <p className="text-3xl font-bold text-[#121212]">{study.metrics.revenue}</p>
                  <p className="text-sm text-gray-500">Revenue Generated</p>
                </div>
              </AnimatedSection>
              <AnimatedSection delay={0.4}>
                <div className="card text-center">
                  <Calendar className="w-8 h-8 text-gray-400 mx-auto mb-2" />
                  <p className="text-3xl font-bold text-[#121212]">{study.metrics.timeline}</p>
                  <p className="text-sm text-gray-500">Timeline</p>
                </div>
              </AnimatedSection>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
              <AnimatedSection className="lg:col-span-2">
                <div className="space-y-8">
                  <div>
                    <h3 className="heading-sm mb-4 flex items-center">
                      <Target className="w-6 h-6 text-[#2E7D32] mr-3" />
                      The Challenge
                    </h3>
                    <p className="text-gray-700 leading-relaxed">{study.challenge}</p>
                  </div>

                  <div>
                    <h3 className="heading-sm mb-4">Our Solution</h3>
                    <p className="text-gray-700 leading-relaxed mb-4">{study.solution}</p>
                    <ul className="space-y-3">
                      {study.systems.map((system, i) => (
                        <li key={i} className="flex items-start">
                          <CheckCircle className="w-5 h-5 text-[#2E7D32] mr-3 mt-0.5 flex-shrink-0" />
                          <span className="text-gray-600">{system}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  <div>
                    <h3 className="heading-sm mb-4 flex items-center">
                      <TrendingUp className="w-6 h-6 text-[#2E7D32] mr-3" />
                      The Results
                    </h3>
                    <p className="text-gray-700 leading-relaxed">{study.results}</p>
                  </div>
                </div>
              </AnimatedSection>

              <AnimatedSection delay={0.2}>
                <div className="card bg-[#121212] text-white sticky top-24">
                  <div className="mb-6">
                    <svg className="w-10 h-10 text-[#2E7D32]" fill="currentColor" viewBox="0 0 24 24">
                      <path d="M14.017 21v-7.391c0-5.704 3.731-9.57 8.983-10.609l.995 2.151c-2.432.917-3.995 3.638-3.995 5.849h4v10h-9.983zm-14.017 0v-7.391c0-5.704 3.748-9.57 9-10.609l.996 2.151c-2.433.917-3.996 3.638-3.996 5.849h3.983v10h-9.983z" />
                    </svg>
                  </div>
                  <p className="text-lg text-gray-200 italic mb-6 leading-relaxed">
                    {study.quote.text}
                  </p>
                  <p className="text-[#2E7D32] font-medium">{study.quote.author}</p>
                </div>
              </AnimatedSection>
            </div>
          </div>
        </section>
      ))}

      <section className="section-padding bg-[#121212]">
        <div className="max-w-3xl mx-auto">
          <AnimatedSection className="text-center mb-10">
            <h2 className="heading-lg text-white mb-4">
              Want Results Like These?
            </h2>
            <p className="body-lg text-gray-300">
              Every business is unique, but our proven systems deliver consistent results. Let's discuss how we can help you achieve predictable growth.
            </p>
          </AnimatedSection>

          <AnimatedSection>
            <div className="bg-white rounded-2xl p-8 md:p-10">
              <LeadForm source="case_studies_page" />
            </div>
          </AnimatedSection>
        </div>
      </section>
    </main>
  );
}
