import { motion } from 'framer-motion';
import { Zap, Target, TrendingUp, Award, Users, BarChart } from 'lucide-react';
import AnimatedSection from '../components/AnimatedSection';
import ServiceCard from '../components/ServiceCard';

const services = [
  {
    icon: Target,
    title: 'Digital Strategy',
    description: 'Comprehensive digital strategies tailored to your business goals, market position, and target audience.',
    features: [
      'Market Research & Analysis',
      'Competitor Analysis',
      'Customer Journey Mapping',
      'Digital Transformation Planning'
    ]
  },
  {
    icon: TrendingUp,
    title: 'Growth Marketing',
    description: 'Data-driven marketing campaigns designed to accelerate growth and maximize ROI.',
    features: [
      'Performance Marketing',
      'Conversion Rate Optimization',
      'Marketing Automation',
      'Growth Hacking Strategies'
    ]
  },
  {
    icon: BarChart,
    title: 'Analytics & Insights',
    description: 'Turn data into actionable insights with advanced analytics and reporting solutions.',
    features: [
      'Custom Analytics Setup',
      'Data Visualization',
      'Performance Tracking',
      'Predictive Analytics'
    ]
  },
  {
    icon: Users,
    title: 'Social Media Management',
    description: 'Build and engage your community with strategic social media management and content creation.',
    features: [
      'Content Strategy & Creation',
      'Community Management',
      'Influencer Partnerships',
      'Social Advertising'
    ]
  },
  {
    icon: Zap,
    title: 'Brand Development',
    description: 'Create a powerful brand identity that resonates with your audience and stands out in the market.',
    features: [
      'Brand Strategy',
      'Visual Identity Design',
      'Brand Guidelines',
      'Brand Positioning'
    ]
  },
  {
    icon: Award,
    title: 'Consulting Services',
    description: 'Expert guidance and strategic advice to overcome challenges and seize opportunities.',
    features: [
      'Marketing Audits',
      'Strategic Planning',
      'Team Training',
      'Ongoing Support'
    ]
  }
];

export default function ServicesPage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-slate-100">
      <div className="relative h-80 overflow-hidden">
        <img
          src="https://images.pexels.com/photos/3183197/pexels-photo-3183197.jpeg?auto=compress&cs=tinysrgb&w=1600"
          alt="Professional services"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-black/60 to-black/40"></div>
        <div className="absolute inset-0 flex items-center justify-center">
          <motion.h1
            className="text-4xl sm:text-5xl lg:text-6xl font-bold text-white text-center px-4"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            Our Services
          </motion.h1>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 sm:py-24">
        <AnimatedSection>
          <div className="text-center mb-16">
            <motion.p
              className="text-lg sm:text-xl text-slate-600 max-w-3xl mx-auto leading-relaxed"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.1 }}
            >
              Comprehensive digital marketing solutions designed to drive growth,
              enhance your brand, and deliver measurable results.
            </motion.p>
          </div>
        </AnimatedSection>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service, index) => (
            <AnimatedSection key={index} delay={index * 0.1}>
              <ServiceCard {...service} />
            </AnimatedSection>
          ))}
        </div>

        <AnimatedSection delay={0.6}>
          <div className="mt-20 bg-gradient-to-r from-blue-600 to-cyan-600 rounded-2xl p-8 sm:p-12 text-center shadow-xl">
            <h2 className="text-3xl sm:text-4xl font-bold text-white mb-4">
              Ready to Transform Your Digital Presence?
            </h2>
            <p className="text-lg sm:text-xl text-blue-100 mb-8 max-w-2xl mx-auto">
              Let's discuss how our services can help you achieve your business goals.
            </p>
            <a
              href="/contact"
              className="inline-block bg-white text-blue-600 px-8 py-4 rounded-xl font-semibold hover:bg-blue-50 transition-all duration-300 transform hover:scale-105 shadow-lg"
            >
              Get Started Today
            </a>
          </div>
        </AnimatedSection>
      </div>
    </div>
  );
}
