import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

export interface Lead {
  id?: string;
  name: string;
  email: string;
  phone?: string;
  business_type: string;
  website_url?: string;
  pain_point?: string;
  source?: string;
  niche_param?: string;
  created_at?: string;
  email_sent?: boolean;
  nurture_day?: number;
}

export async function submitLead(lead: Lead): Promise<{ success: boolean; error?: string }> {
  const { error } = await supabase.from('leads').insert([lead]);

  if (error) {
    console.error('Error submitting lead:', error);
    return { success: false, error: error.message };
  }

  return { success: true };
}

export async function getLeads(): Promise<Lead[]> {
  const { data, error } = await supabase
    .from('leads')
    .select('*')
    .order('created_at', { ascending: false });

  if (error) {
    console.error('Error fetching leads:', error);
    return [];
  }

  return data || [];
}

export async function deleteLead(id: string): Promise<boolean> {
  const { error } = await supabase.from('leads').delete().eq('id', id);
  return !error;
}

export async function updateLead(id: string, updates: Partial<Lead>): Promise<boolean> {
  const { error } = await supabase.from('leads').update(updates).eq('id', id);
  return !error;
}

export async function verifyAdmin(username: string, password: string): Promise<boolean> {
  const { data } = await supabase
    .from('admin_users')
    .select('password_hash')
    .eq('username', username)
    .maybeSingle();

  if (!data) return false;
  return data.password_hash === `${password}_hashed`;
}

export async function updateAdminPassword(username: string, newPassword: string): Promise<boolean> {
  const { error } = await supabase
    .from('admin_users')
    .update({ password_hash: `${newPassword}_hashed` })
    .eq('username', username);

  return !error;
}

export async function getLeadStats(): Promise<{
  total: number;
  thisMonth: number;
  byType: Record<string, number>;
}> {
  const { data } = await supabase.from('leads').select('*');

  if (!data) return { total: 0, thisMonth: 0, byType: {} };

  const now = new Date();
  const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);

  const thisMonth = data.filter(
    (lead) => new Date(lead.created_at) >= startOfMonth
  ).length;

  const byType = data.reduce((acc, lead) => {
    acc[lead.business_type] = (acc[lead.business_type] || 0) + 1;
    return acc;
  }, {} as Record<string, number>);

  return { total: data.length, thisMonth, byType };
}
