import { motion } from 'framer-motion';
import { LucideIcon } from 'lucide-react';

interface ServiceCardProps {
  icon: LucideIcon;
  title: string;
  description: string;
  index?: number;
}

export default function ServiceCard({ icon: Icon, title, description, index = 0 }: ServiceCardProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ delay: index * 0.1, duration: 0.5 }}
      className="card group"
    >
      <div className="w-12 h-12 bg-[#2E7D32]/10 rounded-xl flex items-center justify-center mb-6 group-hover:bg-[#2E7D32]/20 transition-colors">
        <Icon className="w-6 h-6 text-[#2E7D32]" />
      </div>
      <h3 className="text-lg font-semibold mb-3 text-[#121212]">{title}</h3>
      <p className="text-gray-600 text-sm leading-relaxed">{description}</p>
    </motion.div>
  );
}
