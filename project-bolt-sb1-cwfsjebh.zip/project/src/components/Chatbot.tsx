import { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { MessageCircle, X, Send, Bot, User } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

interface Message {
  id: number;
  text: string;
  isBot: boolean;
  options?: string[];
}

const initialMessages: Message[] = [
  {
    id: 1,
    text: "Hi there! I'm here to help you grow your business. What brings you to CGS today?",
    isBot: true,
    options: [
      "I need more leads",
      "I want to learn about your services",
      "I have questions about pricing",
      "I'd like a free audit"
    ]
  }
];

const responses: Record<string, { text: string; options?: string[]; action?: string }> = {
  "I need more leads": {
    text: "You're in the right place! We help service businesses generate 20-50 qualified leads per month. What type of business do you run?",
    options: ["Gym or Fitness Studio", "Coaching or Consulting", "Financial Services", "Roofing or Trades", "Other Service Business"]
  },
  "Gym or Fitness Studio": {
    text: "Great! We've helped gyms add 35+ leads in just 14 days. Our system combines local SEO, targeted ads, and smart website features. Would you like to see how we can do the same for you?",
    options: ["Yes, book a free audit", "Tell me more about the process", "Show me case studies"]
  },
  "Coaching or Consulting": {
    text: "Perfect! We recently helped a coaching client generate 45 qualified leads in 21 days, resulting in 12 new sign-ups. Our funnels and automation are designed specifically for coaches.",
    options: ["Yes, book a free audit", "Tell me more about the process", "Show me case studies"]
  },
  "Financial Services": {
    text: "Excellent! We helped a financial advisor get 28 qualified leads in 18 days. Our AI-driven campaigns position you as an expert and attract high-value clients.",
    options: ["Yes, book a free audit", "Tell me more about the process", "Show me case studies"]
  },
  "Roofing or Trades": {
    text: "We work with several trades businesses. Our local SEO and targeted ad systems are perfect for capturing customers searching for services in your area.",
    options: ["Yes, book a free audit", "Tell me more about the process", "Show me case studies"]
  },
  "Other Service Business": {
    text: "We work with all kinds of service businesses. The key is having a system that brings in qualified leads consistently. Tell me more about your business in a free audit.",
    options: ["Yes, book a free audit", "Tell me more about the process"]
  },
  "I want to learn about your services": {
    text: "We offer complete customer acquisition systems including: smart website upgrades, high-converting funnels, targeted ads, local SEO, email automation, and AI-powered campaigns. Which interests you most?",
    options: ["Website & Funnels", "Paid Advertising", "Local SEO", "Email Automation", "All of the above"]
  },
  "Website & Funnels": {
    text: "Our websites and funnels are designed to convert visitors 24/7. We add lead capture forms, chatbots, and exit-intent popups to turn browsers into leads.",
    options: ["Yes, book a free audit", "Tell me about pricing"]
  },
  "Paid Advertising": {
    text: "We run targeted campaigns on Facebook, Instagram, and Google to reach ready-to-buy customers. We optimize for conversions, not vanity metrics.",
    options: ["Yes, book a free audit", "Tell me about pricing"]
  },
  "Local SEO": {
    text: "We help you dominate local search results for terms like 'gym near me' or '[service] in [city]'. This brings in free, high-intent traffic.",
    options: ["Yes, book a free audit", "Tell me about pricing"]
  },
  "Email Automation": {
    text: "Our email sequences nurture leads automatically, turning interest into sales while you focus on running your business.",
    options: ["Yes, book a free audit", "Tell me about pricing"]
  },
  "All of the above": {
    text: "Smart choice! Our complete systems combine all these elements for maximum impact. Most clients see 20-50 qualified leads per month.",
    options: ["Yes, book a free audit", "Tell me about pricing"]
  },
  "I have questions about pricing": {
    text: "Our pricing is customized based on your specific needs and goals. We focus on ROI, and we offer a money-back guarantee if we don't deliver results. The best way to get accurate pricing is through a free audit.",
    options: ["Yes, book a free audit", "What's included in the audit?"]
  },
  "Tell me about pricing": {
    text: "Pricing varies based on which services you need. We always start with a free audit to understand your business and provide accurate quotes. Plus, we guarantee results or your money back.",
    options: ["Yes, book a free audit", "What's the guarantee?"]
  },
  "What's the guarantee?": {
    text: "If we don't deliver 20-50 qualified leads per month, you get your money back. We're that confident in our systems because we only take 5 clients per month to ensure exceptional results.",
    options: ["Yes, book a free audit", "Why only 5 clients?"]
  },
  "Why only 5 clients?": {
    text: "Quality over quantity. By limiting our client intake, we ensure every business gets the attention it deserves. This is how we maintain our results and money-back guarantee.",
    options: ["Yes, book a free audit", "Show me case studies"]
  },
  "I'd like a free audit": {
    text: "Excellent choice! Our free growth audit will analyze your current marketing and identify exactly how to get more qualified leads. Ready to get started?",
    action: "contact"
  },
  "Yes, book a free audit": {
    text: "Great! Let me take you to our booking form where you can schedule your free growth audit. Our team will analyze your business and provide actionable recommendations.",
    action: "contact"
  },
  "Tell me more about the process": {
    text: "Our process has 4 steps: 1) We diagnose your business model, 2) Identify your ideal customers, 3) Build your custom lead system, 4) Deliver measurable ROI. Simple and effective.",
    options: ["Yes, book a free audit", "Show me case studies"]
  },
  "Show me case studies": {
    text: "We have several success stories: a coaching client got 45 leads in 21 days, a gym got 35 leads in 14 days, and a financial advisor got 28 leads in 18 days. Want to see the full details?",
    action: "case-studies"
  },
  "What's included in the audit?": {
    text: "The free audit includes: analysis of your current marketing, identification of growth opportunities, custom strategy recommendations, and clear next steps. No obligation, just valuable insights.",
    options: ["Yes, book a free audit", "How long does it take?"]
  },
  "How long does it take?": {
    text: "The audit call takes about 30 minutes. We'll review your business, discuss your goals, and provide actionable recommendations you can use whether you work with us or not.",
    options: ["Yes, book a free audit"]
  }
};

export default function Chatbot() {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<Message[]>(initialMessages);
  const [inputValue, setInputValue] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const navigate = useNavigate();

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleOptionClick = (option: string) => {
    const userMessage: Message = {
      id: messages.length + 1,
      text: option,
      isBot: false
    };

    setMessages(prev => [...prev, userMessage]);

    setTimeout(() => {
      const response = responses[option];
      if (response) {
        if (response.action === 'contact') {
          const botMessage: Message = {
            id: messages.length + 2,
            text: response.text,
            isBot: true
          };
          setMessages(prev => [...prev, botMessage]);
          setTimeout(() => {
            navigate('/contact');
            setIsOpen(false);
          }, 1500);
        } else if (response.action === 'case-studies') {
          const botMessage: Message = {
            id: messages.length + 2,
            text: response.text,
            isBot: true
          };
          setMessages(prev => [...prev, botMessage]);
          setTimeout(() => {
            navigate('/case-studies');
            setIsOpen(false);
          }, 1500);
        } else {
          const botMessage: Message = {
            id: messages.length + 2,
            text: response.text,
            isBot: true,
            options: response.options
          };
          setMessages(prev => [...prev, botMessage]);
        }
      } else {
        const botMessage: Message = {
          id: messages.length + 2,
          text: "I'd love to help you with that. The best way to get specific answers is through a free growth audit with our team.",
          isBot: true,
          options: ["Yes, book a free audit", "I have another question"]
        };
        setMessages(prev => [...prev, botMessage]);
      }
    }, 500);
  };

  const handleSendMessage = () => {
    if (!inputValue.trim()) return;

    const userMessage: Message = {
      id: messages.length + 1,
      text: inputValue,
      isBot: false
    };

    setMessages(prev => [...prev, userMessage]);
    setInputValue('');

    setTimeout(() => {
      const botMessage: Message = {
        id: messages.length + 2,
        text: "Thanks for your message! For personalized answers about your specific situation, I recommend booking a free growth audit. Our team can analyze your business and provide tailored recommendations.",
        isBot: true,
        options: ["Yes, book a free audit", "Tell me more about your services"]
      };
      setMessages(prev => [...prev, botMessage]);
    }, 800);
  };

  return (
    <>
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: 20, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 20, scale: 0.95 }}
            className="fixed bottom-24 right-6 w-[380px] max-w-[calc(100vw-48px)] bg-white rounded-2xl shadow-2xl z-50 overflow-hidden"
          >
            <div className="bg-[#121212] text-white p-4 flex items-center justify-between">
              <div className="flex items-center">
                <div className="w-10 h-10 bg-[#2E7D32] rounded-full flex items-center justify-center mr-3">
                  <Bot className="w-5 h-5" />
                </div>
                <div>
                  <p className="font-semibold text-sm">CGS Growth Assistant</p>
                  <p className="text-xs text-gray-400">Typically replies instantly</p>
                </div>
              </div>
              <button
                onClick={() => setIsOpen(false)}
                className="text-gray-400 hover:text-white transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="h-[350px] overflow-y-auto p-4 space-y-4 bg-gray-50">
              {messages.map((message) => (
                <div key={message.id}>
                  <div className={`flex items-start ${message.isBot ? '' : 'justify-end'}`}>
                    {message.isBot && (
                      <div className="w-8 h-8 bg-[#2E7D32] rounded-full flex items-center justify-center mr-2 flex-shrink-0">
                        <Bot className="w-4 h-4 text-white" />
                      </div>
                    )}
                    <div
                      className={`max-w-[80%] p-3 rounded-2xl text-sm ${
                        message.isBot
                          ? 'bg-white text-gray-700 rounded-tl-none shadow-sm'
                          : 'bg-[#2E7D32] text-white rounded-tr-none'
                      }`}
                    >
                      {message.text}
                    </div>
                    {!message.isBot && (
                      <div className="w-8 h-8 bg-gray-300 rounded-full flex items-center justify-center ml-2 flex-shrink-0">
                        <User className="w-4 h-4 text-gray-600" />
                      </div>
                    )}
                  </div>
                  {message.options && (
                    <div className="mt-3 ml-10 flex flex-wrap gap-2">
                      {message.options.map((option, index) => (
                        <button
                          key={index}
                          onClick={() => handleOptionClick(option)}
                          className="text-xs bg-white border border-gray-200 text-gray-700 px-3 py-2 rounded-full hover:border-[#2E7D32] hover:text-[#2E7D32] transition-colors"
                        >
                          {option}
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              ))}
              <div ref={messagesEndRef} />
            </div>

            <div className="p-4 border-t border-gray-200 bg-white">
              <div className="flex items-center space-x-2">
                <input
                  type="text"
                  value={inputValue}
                  onChange={(e) => setInputValue(e.target.value)}
                  onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
                  placeholder="Type your message..."
                  className="flex-1 px-4 py-2 border border-gray-200 rounded-full text-sm focus:outline-none focus:border-[#2E7D32]"
                />
                <button
                  onClick={handleSendMessage}
                  className="w-10 h-10 bg-[#2E7D32] text-white rounded-full flex items-center justify-center hover:bg-[#256428] transition-colors"
                >
                  <Send className="w-4 h-4" />
                </button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <motion.button
        onClick={() => setIsOpen(!isOpen)}
        className="fixed bottom-6 right-6 w-14 h-14 bg-[#2E7D32] text-white rounded-full shadow-lg flex items-center justify-center z-50 hover:bg-[#256428] transition-colors"
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
      >
        {isOpen ? <X className="w-6 h-6" /> : <MessageCircle className="w-6 h-6" />}
      </motion.button>
    </>
  );
}
