import { Link } from 'react-router-dom';
import { Mail, Phone, Linkedin, Twitter, Facebook, Instagram } from 'lucide-react';
import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';

const footerLinks = {
  navigation: [
    { href: '/', label: 'Home' },
    { href: '/about', label: 'About' },
    { href: '/services', label: 'Services' },
    { href: '/case-studies', label: 'Case Studies' },
    { href: '/resources', label: 'Resources' },
    { href: '/contact', label: 'Contact' }
  ],
  resources: [
    { href: '/resources#lead-funnel', label: 'Lead Funnel Guide' },
    { href: '/resources#ad-mistakes', label: 'Ad Optimization Tips' },
    { href: '/resources#local-seo', label: 'Local SEO Guide' },
    { href: '/resources#email-automation', label: 'Email Automation' }
  ]
};

interface SocialLinks {
  instagram: string;
  linkedin: string;
  twitter: string;
  facebook: string;
}

export default function Footer() {
  const [socialLinks, setSocialLinks] = useState<SocialLinks>({
    instagram: 'https://instagram.com/cgsleads',
    linkedin: 'https://www.linkedin.com/company/client-growth-systems',
    twitter: 'https://twitter.com/cgrowthsystems',
    facebook: 'https://facebook.com/clientgrowthsystems'
  });

  useEffect(() => {
    const fetchSocialLinks = async () => {
      const { data } = await supabase
        .from('settings')
        .select('instagram_url, linkedin_url, twitter_url, facebook_url')
        .single();

      if (data) {
        setSocialLinks({
          instagram: data.instagram_url || socialLinks.instagram,
          linkedin: data.linkedin_url || socialLinks.linkedin,
          twitter: data.twitter_url || socialLinks.twitter,
          facebook: data.facebook_url || socialLinks.facebook
        });
      }
    };

    fetchSocialLinks();
  }, []);

  return (
    <footer className="bg-[#121212] text-white">
      <div className="max-w-7xl mx-auto px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12">
          <div className="space-y-6">
            <div className="flex items-center space-x-3">
              <img
                src="/img_8040.jpeg"
                alt="Client Growth Systems Logo"
                className="h-14 w-auto"
              />
              <span className="text-lg font-semibold">Client Growth Systems</span>
            </div>
            <p className="text-gray-400 text-sm leading-relaxed">
              Predictable Growth Through Smart Systems
            </p>
            <div className="flex space-x-4">
              <a
                href={socialLinks.instagram}
                target="_blank"
                rel="noopener noreferrer"
                className="w-9 h-9 flex items-center justify-center rounded-full bg-gray-800 hover:bg-[#2E7D32] text-gray-400 hover:text-white transition-all"
                aria-label="Instagram"
              >
                <Instagram size={18} />
              </a>
              <a
                href={socialLinks.linkedin}
                target="_blank"
                rel="noopener noreferrer"
                className="w-9 h-9 flex items-center justify-center rounded-full bg-gray-800 hover:bg-[#2E7D32] text-gray-400 hover:text-white transition-all"
                aria-label="LinkedIn"
              >
                <Linkedin size={18} />
              </a>
              <a
                href={socialLinks.twitter}
                target="_blank"
                rel="noopener noreferrer"
                className="w-9 h-9 flex items-center justify-center rounded-full bg-gray-800 hover:bg-[#2E7D32] text-gray-400 hover:text-white transition-all"
                aria-label="Twitter"
              >
                <Twitter size={18} />
              </a>
              <a
                href={socialLinks.facebook}
                target="_blank"
                rel="noopener noreferrer"
                className="w-9 h-9 flex items-center justify-center rounded-full bg-gray-800 hover:bg-[#2E7D32] text-gray-400 hover:text-white transition-all"
                aria-label="Facebook"
              >
                <Facebook size={18} />
              </a>
            </div>
          </div>

          <div>
            <h4 className="font-semibold mb-6">Navigation</h4>
            <ul className="space-y-3">
              {footerLinks.navigation.map((link) => (
                <li key={link.href}>
                  <Link
                    to={link.href}
                    className="text-gray-400 hover:text-white transition-colors text-sm"
                  >
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="font-semibold mb-6">Free Resources</h4>
            <ul className="space-y-3">
              {footerLinks.resources.map((link) => (
                <li key={link.href}>
                  <Link
                    to={link.href}
                    className="text-gray-400 hover:text-white transition-colors text-sm"
                  >
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="font-semibold mb-6">Contact Us</h4>
            <ul className="space-y-4">
              <li>
                <a
                  href="mailto:info@cgsleads.com"
                  className="flex items-center space-x-3 text-gray-400 hover:text-white transition-colors text-sm"
                >
                  <Mail size={18} />
                  <span>info@cgsleads.com</span>
                </a>
              </li>
              <li>
                <a
                  href="mailto:cgs.clientsacquisitions@gmail.com"
                  className="flex items-center space-x-3 text-gray-400 hover:text-white transition-colors text-sm"
                >
                  <Mail size={18} />
                  <span>cgs.clientsacquisitions@gmail.com</span>
                </a>
              </li>
              <li>
                <a
                  href="tel:+447436101043"
                  className="flex items-center space-x-3 text-gray-400 hover:text-white transition-colors text-sm"
                >
                  <Phone size={18} />
                  <span>+44 743 610 1043</span>
                </a>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-gray-800 mt-12 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center space-y-4 md:space-y-0">
            <p className="text-gray-500 text-sm">
              © 2025 Client Growth Systems. All rights reserved. Founded 2025.
            </p>
            <p className="text-gray-500 text-sm italic">
              Predictable Growth Through Smart Systems
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
}
