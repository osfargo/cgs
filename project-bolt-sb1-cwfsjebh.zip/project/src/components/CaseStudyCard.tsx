import { motion } from 'framer-motion';
import { TrendingUp, Users, DollarSign } from 'lucide-react';
import { Link } from 'react-router-dom';

interface CaseStudyCardProps {
  title: string;
  category: string;
  metrics: {
    leads: string;
    conversions: string;
    revenue: string;
  };
  quote: string;
  image?: string;
  index?: number;
}

export default function CaseStudyCard({
  title,
  category,
  metrics,
  quote,
  image,
  index = 0
}: CaseStudyCardProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ delay: index * 0.15, duration: 0.5 }}
      className="card overflow-hidden p-0"
    >
      {image && (
        <div className="relative h-48 overflow-hidden">
          <img
            src={image}
            alt={title}
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"></div>
          <span className="absolute top-4 right-4 px-3 py-1 bg-white/90 backdrop-blur-sm text-[#2E7D32] text-xs font-medium rounded-full">
            {category}
          </span>
        </div>
      )}
      <div className="p-8">
        {!image && (
          <span className="inline-block px-3 py-1 bg-[#2E7D32]/10 text-[#2E7D32] text-xs font-medium rounded-full mb-4">
            {category}
          </span>
        )}
        <h3 className="text-xl font-semibold mb-4 text-[#121212]">{title}</h3>

      <div className="grid grid-cols-3 gap-4 mb-6">
        <div className="text-center p-3 bg-gray-50 rounded-lg">
          <Users className="w-5 h-5 text-[#1976D2] mx-auto mb-1" />
          <p className="text-lg font-bold text-[#121212]">{metrics.leads}</p>
          <p className="text-xs text-gray-500">Leads</p>
        </div>
        <div className="text-center p-3 bg-gray-50 rounded-lg">
          <TrendingUp className="w-5 h-5 text-[#2E7D32] mx-auto mb-1" />
          <p className="text-lg font-bold text-[#121212]">{metrics.conversions}</p>
          <p className="text-xs text-gray-500">Conversions</p>
        </div>
        <div className="text-center p-3 bg-gray-50 rounded-lg">
          <DollarSign className="w-5 h-5 text-[#2E7D32] mx-auto mb-1" />
          <p className="text-lg font-bold text-[#121212]">{metrics.revenue}</p>
          <p className="text-xs text-gray-500">Revenue</p>
        </div>
      </div>

        <blockquote className="text-gray-600 text-sm italic border-l-2 border-[#2E7D32] pl-4 mb-6">
          "{quote}"
        </blockquote>

        <Link to="/case-studies" className="link-blue text-sm font-medium">
          Read Full Case Study
        </Link>
      </div>
    </motion.div>
  );
}
