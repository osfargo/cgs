import { useState } from 'react';
import { motion } from 'framer-motion';
import { CheckCircle, Loader2 } from 'lucide-react';
import { submitLead } from '../lib/supabase';
import { usePersonalization } from '../context/PersonalizationContext';

const businessTypes = [
  { value: 'coach', label: 'Coach / Consultant' },
  { value: 'advisor', label: 'Financial Advisor' },
  { value: 'gym', label: 'Gym / Fitness Studio' },
  { value: 'builder', label: 'Builder / Contractor' },
  { value: 'other', label: 'Other Service Business' }
];

interface LeadFormProps {
  source?: string;
  compact?: boolean;
}

export default function LeadForm({ source = 'website', compact = false }: LeadFormProps) {
  const { niche } = usePersonalization();
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    business_type: niche !== 'default' ? niche : '',
    website_url: '',
    pain_point: ''
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    setError('');

    const result = await submitLead({
      ...formData,
      source,
      niche_param: niche !== 'default' ? niche : undefined
    });

    if (result.success) {
      setIsSuccess(true);
    } else {
      setError('Something went wrong. Please try again or email us directly.');
    }

    setIsSubmitting(false);
  };

  if (isSuccess) {
    return (
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="text-center py-12"
      >
        <CheckCircle className="w-16 h-16 text-[#2E7D32] mx-auto mb-6" />
        <h3 className="heading-sm mb-4">You're on the List!</h3>
        <p className="body-md max-w-md mx-auto">
          Thank you for your interest. We'll review your submission and reach out within 24 hours with your free growth audit. Check your email for a confirmation and some valuable resources.
        </p>
      </motion.div>
    );
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-5">
      <div className={compact ? 'space-y-4' : 'grid grid-cols-1 md:grid-cols-2 gap-5'}>
        <div>
          <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-2">
            Full Name *
          </label>
          <input
            type="text"
            id="name"
            required
            value={formData.name}
            onChange={(e) => setFormData({ ...formData, name: e.target.value })}
            className="input-field"
            placeholder="John Smith"
          />
        </div>

        <div>
          <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-2">
            Email Address *
          </label>
          <input
            type="email"
            id="email"
            required
            value={formData.email}
            onChange={(e) => setFormData({ ...formData, email: e.target.value })}
            className="input-field"
            placeholder="john@company.com"
          />
        </div>

        <div>
          <label htmlFor="phone" className="block text-sm font-medium text-gray-700 mb-2">
            Phone Number
          </label>
          <input
            type="tel"
            id="phone"
            value={formData.phone}
            onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
            className="input-field"
            placeholder="+44 123 456 789"
          />
        </div>

        <div>
          <label htmlFor="business_type" className="block text-sm font-medium text-gray-700 mb-2">
            Business Type *
          </label>
          <select
            id="business_type"
            required
            value={formData.business_type}
            onChange={(e) => setFormData({ ...formData, business_type: e.target.value })}
            className="input-field"
          >
            <option value="">Select your business type</option>
            {businessTypes.map((type) => (
              <option key={type.value} value={type.value}>
                {type.label}
              </option>
            ))}
          </select>
        </div>

        {!compact && (
          <div>
            <label htmlFor="website_url" className="block text-sm font-medium text-gray-700 mb-2">
              Website URL
            </label>
            <input
              type="url"
              id="website_url"
              value={formData.website_url}
              onChange={(e) => setFormData({ ...formData, website_url: e.target.value })}
              className="input-field"
              placeholder="https://yourcompany.com"
            />
          </div>
        )}
      </div>

      {!compact && (
        <div>
          <label htmlFor="pain_point" className="block text-sm font-medium text-gray-700 mb-2">
            What's Your Biggest Pain Point? *
          </label>
          <textarea
            id="pain_point"
            required
            rows={4}
            value={formData.pain_point}
            onChange={(e) => setFormData({ ...formData, pain_point: e.target.value })}
            className="input-field resize-none"
            placeholder="Tell us about your biggest challenge with getting new customers..."
          />
        </div>
      )}

      {error && (
        <p className="text-red-600 text-sm">{error}</p>
      )}

      <button
        type="submit"
        disabled={isSubmitting}
        className="btn-primary w-full flex items-center justify-center space-x-2"
      >
        {isSubmitting ? (
          <>
            <Loader2 className="w-5 h-5 animate-spin" />
            <span>Submitting...</span>
          </>
        ) : (
          <span>Join Waiting List & Get Free Audit</span>
        )}
      </button>

      <p className="text-xs text-gray-500 text-center">
        We respect your privacy. Your information is secure and will never be shared.
      </p>
    </form>
  );
}
