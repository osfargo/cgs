import { createContext, useContext, useEffect, useState, ReactNode } from 'react';

type NicheType = 'gym' | 'roofer' | 'dentist' | 'coach' | 'advisor' | 'default';

interface NicheContent {
  headline: string;
  subheadline: string;
  targetAudience: string;
  painPoints: string[];
  cta: string;
}

const nicheContent: Record<NicheType, NicheContent> = {
  gym: {
    headline: 'Get 20-50 New Gym Members Per Month',
    subheadline: 'Fill your classes and membership roster predictably',
    targetAudience: 'gym owners and fitness studios',
    painPoints: [
      'Empty classes during off-peak hours',
      'High member churn rates',
      'Inconsistent new member sign-ups'
    ],
    cta: 'Start Filling Your Gym'
  },
  roofer: {
    headline: 'Get 20-50 Qualified Roofing Leads Per Month',
    subheadline: 'Book more jobs with homeowners ready to buy',
    targetAudience: 'roofing contractors',
    painPoints: [
      'Wasted time on tire-kickers',
      'Seasonal income fluctuations',
      'Expensive leads that never convert'
    ],
    cta: 'Start Getting Roofing Leads'
  },
  dentist: {
    headline: 'Get 20-50 New Dental Patients Per Month',
    subheadline: 'Keep your chairs full with quality patients',
    targetAudience: 'dental practices',
    painPoints: [
      'Empty appointment slots',
      'Low-value patients seeking discounts',
      'Inconsistent patient flow'
    ],
    cta: 'Start Growing Your Practice'
  },
  coach: {
    headline: 'Get 20-50 Coaching Clients Per Month',
    subheadline: 'Fill your calendar with clients ready to invest',
    targetAudience: 'coaches and consultants',
    painPoints: [
      'Feast-or-famine income cycles',
      'Spending hours on discovery calls that go nowhere',
      'Competing on price instead of value'
    ],
    cta: 'Start Attracting Premium Clients'
  },
  advisor: {
    headline: 'Get 20-50 High-Net-Worth Leads Per Month',
    subheadline: 'Connect with clients ready to plan their financial future',
    targetAudience: 'financial advisors and planners',
    painPoints: [
      'Difficulty reaching affluent prospects',
      'Long sales cycles with no commitment',
      'Compliance-heavy marketing limitations'
    ],
    cta: 'Start Attracting Qualified Clients'
  },
  default: {
    headline: 'Get 20-50 Qualified Leads Per Month or Your Money Back',
    subheadline: 'Predictable Growth Through Smart Systems',
    targetAudience: 'service businesses',
    painPoints: [
      'Inconsistent customer flow',
      'Wasted ad spend',
      'Unpredictable revenue'
    ],
    cta: 'Join Waiting List'
  }
};

interface PersonalizationContextType {
  niche: NicheType;
  content: NicheContent;
  setNiche: (niche: NicheType) => void;
}

const PersonalizationContext = createContext<PersonalizationContextType | undefined>(undefined);

export function PersonalizationProvider({ children }: { children: ReactNode }) {
  const [niche, setNiche] = useState<NicheType>('default');

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const nicheParam = params.get('niche')?.toLowerCase() as NicheType;

    if (nicheParam && nicheContent[nicheParam]) {
      setNiche(nicheParam);
    }
  }, []);

  return (
    <PersonalizationContext.Provider
      value={{
        niche,
        content: nicheContent[niche],
        setNiche
      }}
    >
      {children}
    </PersonalizationContext.Provider>
  );
}

export function usePersonalization() {
  const context = useContext(PersonalizationContext);
  if (!context) {
    throw new Error('usePersonalization must be used within PersonalizationProvider');
  }
  return context;
}
